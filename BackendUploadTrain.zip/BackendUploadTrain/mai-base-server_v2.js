const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { exec } = require('child_process');

const app = express();
const port = 4040;

app.use(express.json());
app.use(express.static(__dirname));

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const modelName = req.body.modelName;
    const uploadDir = path.join(__dirname, 'pdf_usr_uploads', modelName);
    fs.mkdirSync(uploadDir, { recursive: true });
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    cb(null, file.originalname);
  }
});

const upload = multer({ storage });

app.post('/receivepdfandtrain', upload.array('pdfs'), (req, res) => {
  const modelName = req.body.modelName;
  const uploadDir = path.join(__dirname, 'pdf_usr_uploads', modelName);
  const dataDir = path.join(uploadDir, `${modelName}-data`);

  const uploadedFiles = req.files;
  uploadedFiles.forEach((file, index) => {
    const oldPath = file.path;
    const newPath = path.join(uploadDir, `pdf_${index + 1}.pdf`);
    fs.renameSync(oldPath, newPath);
  });

  fs.mkdirSync(dataDir, { recursive: true });

  const command = `marker "${uploadDir}" "${dataDir}" --workers 4 --max 10`;
  exec(command, (error, stdout, stderr) => {
    if (error) {
      console.error(`Execution error: ${error.message}`);
      return res.status(500).send('Error processing PDFs');
    }
    console.log(`stdout: ${stdout}`);
    console.error(`stderr: ${stderr}`);

    const uploadedFilesNames = uploadedFiles.map((file, index) => `pdf_${index + 1}.pdf`);
    const htmlContent = `
      <script>
        localStorage.setItem('modelName', '${modelName}');
        localStorage.setItem('uploadedFiles', '${JSON.stringify(uploadedFilesNames)}');
        window.location.href = 'train_models_v2.html';
      </script>
    `;
    res.send(htmlContent);
  });
});

app.post('/convertData', (req, res) => {
    const modelName = req.body.modelName; // Pass model name dynamically
    const command = `python3 convertData.py ${modelName}`;
    
    exec(command, (error, stdout, stderr) => {
      if (error) {
        console.error(`Execution error: ${error.message}`);
        return res.status(500).send('Error converting data');
      }
      console.log(`stdout: ${stdout}`);
      console.error(`stderr: ${stderr}`);
      res.send('¡Optimización completada!');
    });
  });

app.post('/trainModel', (req, res) => {
  const modelName = req.body.modelName; // Pass model name dynamically
  const command = `python3 trainModel.py ${modelName}`;
  
  exec(command, (error, stdout, stderr) => {
    if (error) {
      console.error(`Execution error: ${error.message}`);
      return res.status(500).send('Error training model');
    }
    console.log(`stdout: ${stdout}`);
    console.error(`stderr: ${stderr}`);
    res.send('¡Entrenamiento Completado!');
  });
});

app.post('/generate', upload.single('image'), (req, res) => {
  const inputText = req.body.input_text; // User's input text
  const sessionId = req.body.session_id || "[]"; // Session ID for context, default to empty array
  const imagePath = req.file ? req.file.path : null; // Path to the uploaded image, if provided

  const command = `python3 generate.py "${inputText}" "${imagePath || ''}" '${sessionId}'`;

  exec(command, (error, stdout, stderr) => {
    if (error) {
      console.error(`Execution error: ${error.message}`);
      return res.status(500).send({ error: 'Error generating response' });
    }

    try {
      const result = JSON.parse(stdout); // Parse the JSON output from generate.py
      res.send(result); // Send the result back to the client
    } catch (err) {
      console.error('Error parsing response:', err);
      res.status(500).send({ error: 'Invalid response from Python script' });
    }
  });
});


app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
