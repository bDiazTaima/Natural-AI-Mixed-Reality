- 1 - 

Fuente: Historia del Arte.- Figueroba.- Mc Graw Hill.- 2004 Apreciación del Arte APRECIACIÓN ESTÉTICA: Rama de la filosofía relacionada con la belleza y la fealdad, también se ocupa de saber si estas características están de manera objetiva o sólo en la mente del individuo. Los objetos pueden ser percibidos de un modo particular que es el modo estético o tienen en sí mismas cualidades específicas estéticas. La estética nos permite distinguir entre lo bello y lo feo. 

-El Filósofo Alemán Alexander Gottlieb Baumgarten le puso nombre a la estética. 

 Cosmología *Naturaleza* Psicología racional Teórica o especulativa Critica FILOSOFÍA *Metafísica* Ontología Teodicea *Lógica* Práctica Ética 
 *Estética* RELACIÓN DE LA ESTÉTICA CON OTRAS CIENCIAS 
CRITICA: Se limita analizar las estructuras de las obras de arte, su significado y problemas, comparándolas con otras obras y evaluándolas. 

PSICOLOGÍA DEL ARTE: Se encuentra relacionada con los elementos propios de la psicología como tal, como respuestas humanas al calor, a las formas, palabras y emociones. 

TEORÍAS CLÁSICAS DE LA ESTÉTICA 
PLATÓN: El artista copia un objeto que ya es en si la copia de la realidad.(que sólo puede percibir el filósofo). En la república acusa o desacredita de la sociedad ideal a los artistas, pensaba que las obras de ellos estimulaban la inmoralidad o representaban personajes despreciables, decía que algunas composiciones musicales creaban pereza o incitan a la gente a tomar malas decisiones. 

ARISTÓTELES: Considera el arte como imitación pero en otro sentido. Decía que el arte completaba las cosas hasta donde la naturaleza no pudo llegar. Censuró el arte escénico. 

- 2 - 

Fuente: Historia del Arte.- Figueroba.- Mc Graw Hill.- 2004 IMITACIÓN ARISTOTÉLICA: Toma un objeto de la naturaleza que tiene materia, él separa la materia de la forma, aplica una nueva materia a la misma forma. El arte tiene la finalidad de hacer felices a los hombres. Pensaba que la tragedia estimulaba emociones como el terror o compasión en el espectador, quien llegaba a un punto del catarsis (purgaba los sentimientos). 

Lo estético y lo artístico son diferentes pero complementarios, la obra artística puede considerarse como parte de la estética pero NO todo lo estético es arte.

REDEFINICIÓN DE LA ESTÉTICA (Juan Acha) 
EL PUNTO DE VISTA MATERIALISTA: Nos acercamos a la definición de la estética satisfaciendo nuestras necesidades básicas, es como darnos un lujo. 

EL PUNTO DE VISTA LATINOAMERICANO: Existe una miseria intelectual y cultural que no nos permite tener una percepción real de la estética. 

EL ARTE COMO COMUNICACIÓN 
 
PROCESO: Encodificación Artista Decodificación Espectador CREACIÓN DE LENGUAJES Constante Artista ARTE Y BELLEZA 
A) La belleza de nuestro tiempo Hasta los primeros años de nuestro siglo se pensaba que el arte era sinónimo de belleza o que la belleza estaba implícita, desde que surgió el expresionismo el arte cambio de rumbo y utilizó la fealdad. La fealdad no es un valor estético positivo, pero sí una categoría estética negativa. Lo feo surge como una reacción en contra de lo que se proyecta, generalmente a través de los medios de comunicación como estándar de belleza. 

B) Falacias del arte 1. El arte es belleza (Al principio de Grecia, en cierto momento de la historia del arte se consideró "arte" como sinónimo de belleza). 

CAMPO COMÚN 
MENSAJE 
EMISOR ARTISTA
RECEPTOR ESPECTADOR 
CULTURA 
RETROALIMENTACIÓN 
FEED BACK
SOCIEDAD 
- 3 - 

Fuente: Historia del Arte.- Figueroba.- Mc Graw Hill.- 2004 2. El arte es sentimiento (El arte no es sentimiento, no es sensibilidad, no mientras más lo "sientas" es más artístico) 
3. El arte es realismo fotográfico (No es obligatorio que refleje exactamente la realidad, ni siquiera en las artes plásticas). 

4. El arte es entretenimiento (No tiene la obligación de divertirnos, porque el arte necesita un esfuerzo intelectual para ser entendida y a muchos no les gusta). 

5. El arte es magia (No es sobrenatural) 
C) La clasificación y características de los valores artísticos Éticos Tipos de Estéticos Valores Sociales Económicos El ser humano en vez de estar limitado a consumir la naturaleza para subsistir construye además un mundo distinto del natural en el cual concretamos posibilidades irreales abriéndonos así a un mundo de valores. 

 Jerarquía: Diferentes valores escalonados. 

 Gradación: Ir de más a menos en los valores. 

Características Preferibilidad: Escoger entre varios. Trascendencia: Más allá de lo superficial o temporal. 

 Objetividad: Existen independientes aunque lo percibimos o no. 

- 4 - 

Fuente: Historia del Arte.- Figueroba.- Mc Graw Hill.- 2004 Elementos de las artes plásticas Artes plásticas o visuales: 
CONSIDERADAS ARTES MAYORES Arquitectura Pintura Escultura (*Fotografía) 
CONSIDERADAS ARTES MENORES Las artesanías, como alfarería, cestería, tejido, orfebrería cerámica, talabartería, etc. 

Las artes plásticas implican el saber crear sobre la materia. Es decir, conformar y formar ideas con distintos materiales mediante acciones como la pintura y el dibujo (consideradas "gráficas"), o la arquitectura y la escultura (consideradas "plásticas"). En conjunto, representan una serie de acciones y actividades de tipo gráfico-plástico en donde intervienen la vista y el tacto para apreciarlas y estimular nuestra imaginación y pensamiento. En ellas se unen dos elementos llamados forma y **contenido**: 
Forma En la expresión artística es la determinación, distribución y organización de los elementos que percibimos al apreciar una obra de arte. 

Contenido Es el mensaje, la fuerza, el carácter, la historia o la esencia. Es lo que el artista quiso comunicar con su obra. Implica tiempo, personajes, momento histórico, el discurso implícito, la simbología, etcétera. 

SIN EMBARGO, EN ESTE CAPITULO SÓLO NOS CONCENTRAREMOS EN LOS ELEMENTOS QUE INTERVIENEN EN LA FORMA.

En las artes plásticas hay dos elementos fundamentales que constituyen la base para cualquier composición. Estos son el punto y la línea. 

1.- El punto Considerado como "el sitio de intersección entre dos líneas", es uno de los elementos esenciales de la composición. Se considera "punto" la marca dejada por un lápiz, crayón, plumón o pincel. 

2.- La línea Un punto en movimiento da como resultado una línea, un trazo. Así, una línea está formada por una sucesión de puntos unidos entre sí, tan próximos que no los alcanzamos a distinguir. La línea tiene una sola dimensión y puede ser recta o curva. Según la dirección que tenga, será de diferentes tipos: horizontal, vertical, inclinada, quebrada, curva, ondulada, etc. En relación con otra línea puede ser paralela, perpendicular, divergente, convergente, oblicua, perpendicular, etc. La línea también sugiere volúmenes, construye espacios y crea formas. 

3.- El ritmo: El ritmo es el movimiento que se imprime a la línea. Es la repetición y concordia entre los elementos de la plástica y lo encontramos de diferentes tipos: 
- 5 - 

Fuente: Historia del Arte.- Figueroba.- Mc Graw Hill.- 2004 a) Repetitivo (Cuando los mismos elementos se presentan siempre de igual manera, sin variaciones) b) Alternado (Cuando se van turnando algunos o algunos de los elementos) c) Progresivo (Cuando va de lo bajo a lo alto, de lo alto a lo bajo, de lo pequeño a lo grande o de grande a pequeño) Además, el ritmo no solamente se logra con la línea sino que es posible darlo con otros elementos de la plástica. 

4.- El equilibrio En una composición, el equilibrio se da cuando todos los elementos son necesarios unos a los otros. Decimos que hay equilibrio cuando los elementos de una composición están armonizados de tal manera que no podemos sustituirlos o desplazarlos sin alternar el balance. 

5.- Las formas: a) Geométricas Las formas geométricas básicas son el triángulo, cuadrado y círculo. b) Irregulares, también llamadas orgánicas Son las que no tienen una estructura rígida y pueden ser realizadas premeditadamente, como cuando recreamos la forma de un árbol o hacemos a pulso la silueta de un rostro; o bien, están también las que se hacen de modo accidental, empleando modos diferentes de manchar el papel, goteando tinta o pintura diluida, dejando correr las gotas, empleando colores en spray, salpicando el lienzo con la misma brocha, etcétera. Aquí el único límite es la imaginación. 6.- Espacio Todas las formas quedan plasmadas en alguna superficie. Esa superficie en la que se mueven los elementos como puntos, líneas, colores, formas y texturas, es conocida como el espacio, y también como "plano básico". Los espacios con figuras, imágenes, etc. son llamados espacios positivos. Y los vacíos, espacios negativos. 

7.- Composición Se refiere a la distribución de los elementos en una obra: es el tipo de balance elegido por el artista. Hay de varios tipos: a) Composición simétrica Tiene un eje central y hacia un lado y otro de este eje, la composición es igual: por ejemplo, una mariposa o un rostro completamente de frente. b) Composición asimétrica: En ella, la figura principal está de un lado o de otro. Después se busca el equilibrio, usando color, tamaño o textura. c) Composición radial En ella el foco de interés se encuentra en el centro y todo deriva de él o hacia él. 

8.- Textura La textura se refiere a la apariencia que deja ver la superficie del lienzo, ya sea real o sugerida. Es real cuando al tocarla descubrimos que en efecto es como la vemos, y sugerida cuando sólo es la apariencia la que logra el artista y la "sentimos" visualmente. Entre otros ejemplos de textura están lisa, rugosa, blanda, dura, áspera, suave, etc., e influyen en nuestra percepción al observar determinada obra. 

9.- Color El color puede ser entendido de dos formas, como color-luz y como color-materia. El color-luz parte del descubrimiento de Isaac Newton y su disco cromático. 

- 6 - 

Fuente: Historia del Arte.- Figueroba.- Mc Graw Hill.- 2004 El color-materia es aquel cuya combinación en forma de pigmentos utilizan los artistas. Dos de las propiedades principales del color son el **brillo y el matiz**. a) Brillo Se refiere a la cantidad de luz u oscuridad que hay en un color (de ahí decimos que es pálido o intenso). b)Matiz, que se refiere a la variación del color. 

El color tiene el poder de transmitir diferentes estados de ánimo y además, la historia ha atribuído diferente simbología a cada color. 

Clasificación de los colores: a)Colores primarios:Son el rojo, azul y amarillo, ya que no requieren de ninguna combinación. b)Colores secundarios: Provienen de mezclas de los tres anteriores, de las que resultan tonos como el verde, naranja y violeta. c)Colores terciarios: Son los que combinan entre sí a los primarios y secundarios y dan como resultado el azul-verde, el amarillo-naranja, el azul-violeta etcétera. 

Los tonos Se logran cuando mezclamos un color con mayor o menor cantidad de blanco o negro. Los tonos más claros se obtienen mezclando con blanco y los más oscuros cuando mezclamos con negro. Al conjunto de tonos que obtenemos se le llama **gama** de color . 

Los matices Estos se forman mezclando al color con sus vecinos en el círculo cromático. Por ejemplo, los matices de azul se logran al combinar mayor o menor cantidad de violeta o verde. 

La temperatura del color: a) Colores cálidos: Rojo, naranja y amarillo. Comunican luz y calor y se identifican con sentimientos "vivos" como la euforia, alegría, enojo o ira. 

b) Colores fríos: Azul, verde y violeta. Se relacionan con los bosques, la nieve y el agua; y se identifican con sentimientos relajantes y apacibles, con la meditación, la tranquilidad y la reflexión. 

c) Colores neutros: Gris, café, blanco y negro. Estos no están en el arcoiris y sirven para balancear a los otros colores. 

10.- Dimensiones a) Unidimensionalidad.- Es como una línea que sólo tiene una dimensión: el largo. b) Bidimensionalidad.- Está fomada por dos dimensiones: largo y alto. c) Tridimensionalidad.- Se refiere a tres planos, alto largo y ancho. Esto da el volumen, que puede ser simulado o real. 

11.- El relieve (en escultura) a) Alto relieve.- Cuando más de la mitad de la figura se sale del fondo. b) Medio relieve.- Cuando la mitad de la figura sale del fondo. c) Bajo relieve.- Cuando menos de la mitad de la figura sale del fondo (*) d) Hueco relieve.- Cuando la figura se "hunde" en la obra. 

- 7 - 

Fuente: Historia del Arte.- Figueroba.- Mc Graw Hill.- 2004 12.- Perspectiva Es el punto de vista que el autor quiere ofrecer al espectador. Un buen desarrollo de la perspectiva permite representar correctamente la profundidad sobre una superficie de sólo dos dimensiones. En la perspectiva **paralela,** la línea del horizonte se encuentra con un punto de fuga, en el que convergen todas las diagonales que sirven para proyectar el dibujo. Mientras que en la perspectiva **oblicua** hay dos puntos de fuga y una de las aristas del objeto está de frente a nosotros. 

TECNICAS ARTISTICAS 
1.- PINTURA Y DIBUJO: 
Los conforman tres elementos básicos: 
a) Materiales colorantes: 
+Dibujo: (Lápices de grafito, lápices de color, tinta, carboncillo, bolígrafos. Plumones, marcadores, gises, estilógrafos). +Pintura (de aceite: Óleo; de agua: acuarela, temple, gouache; tintas, anilinas y pinturas acrílicas). 

b)Instrumentos: Pinceles, espátula, lápices, manos, tubos(aplicación directa). 

c)Soportes: Lienzo(tela), papel, lámina galvanizada, madera, pared, etc. 

2.- GRABADO: Puede ser en madera, linóleo, piedra y serigrafía. 

3.- ESCULTURA: Puede ser en bronce, piedra, barro, madera, yeso, acero inoxidable, hierro, cerámica, acrílicos, cristal, oro, plata, etc. 

4.- ARQUITECTURA: Se utiliza materiales vigentes y técnicas constructivas de acuerdo con la época y el medio. 

5.- OTRAS TÉCNICAS: Collage, arte objeto, sculptopintura, land art, body art, arte de procesos, instalación ( obra que se instala en un sitio para causar la sensación de "entrar" a la obra de arte y de alguna manera formar parte de ella) y otros 
- 8 - 

Fuente: Historia del Arte.- Figueroba.- Mc Graw Hill.- 2004 Arte prehistórico PALEOLÍTICO SUPERIOR Data de los años 40,000-10,000 A.C. (Venus de Willendorf) Las expresiones están fundamentadas en una mezcla de magia, religión y expresión de los miedos. El clima es frío, todavía se vive con nomadismo Manifestaciones: Huellas, animales, algunas figuras humanas, el culto a la maternidad. La interpretación de las expresiones artísticas (aunque aún no existe el concepto de arte) es la representación de los hechos, tanto los que ya sucedieron como los hechos por venir, propiedad mágica, anticipatoria. 

MESOLÍTICO Data de los años 10,000-5,000 A.C. El hombre comienza a ser el protagonista, junto con la vida humana y las celebraciones. La pintura es narrativa de sus actividades principales: caza, danza (Imagen de danzantes de "El Cogull") y recolección. 

NEOLÍTICO (Coincide con la edad de piedra ) - 2000 A.C. El hombre comienza a ser sedentario, el clima es mejor y más templado. Comienza a desarrollarse la religión. Comienza a desarrollarse la tecnología: siembra, pan, conocimientos transmitidos, guerra, desarrollo de excedente ( almacenaje ) Expresiones: alfarería, estatuaria, tejidos y megalitismo. 

Megalitismo (edad de piedra ) Primeros elementos arquitectónicos del neolítico y la edad de piedra: Menhir: piedra tallada toscamente asentada en forma vertical Dolmen: Dos menhires cubiertos con uno más que le sirve de tapa o "mesa". Cromlech: Alineación de menhires en forma circular. Ejemplo: Stonehedge (Inglaterra) 
- 9 - 

Fuente: Historia del Arte.- Figueroba.- Mc Graw Hill.- 2004 Arte egipcio La civilización egipcia data, en sus tiempos más antiguos, del año 2000 a.C. Es una civilización que vive para la muerte. 

CARACTERÍSTICAS: Paisaje árido Sobreabundancia de sol El Nilo como una constante Religión politeísta: Ra ( sol ) Isis ( luna) Osiris ( fertilidad ) Apopis ( dragón) Hator ( alegría y el placer) Horus (dios halcón) 
El faraón es una figura de gran importancia, considerada como un Dios, en el marco de la gran esencia de la vida de Egipto, que es la muerte. ARQUITECTURA Tipo Funerario : * Mastabas * Pirámides : Escalonadas ( Djoser) / Clásica ( Keops, Kefrén, Mikerino) * Hipogeos Religioso Templos: ( formado de tres partes: exterior, abiertas, cerrada) obeliscos * Funerarios/Solares * De acción de gracias Civil: Palacios ESTATUARIA Siempre añadida a la arquitectura Tiene la misión de inmortalizar ( realismo ) Convencionalismo Perspectiva Jerárquica (según el personaje se hacía el tamaño de la estatua) 
PINTURAS MURALES Estaban presentes en: Tumbas / Sarcófagos / Cámaras Mortuorias Realismo y frontalidad Uso de colores minerales Temas vida cotidiana y ceremonias Arte Maya 
(en las fotocopias) 
Las formas Griegas I.- Introducción: 
Clima extremoso y difícil, terreno árido y el mar Mediterráneo como una constante, bañando las costas. Buen trabajo portuario. Clima cálido. 

- 10 - 

Fuente: Historia del Arte.- Figueroba.- Mc Graw Hill.- 2004 Orígenes históricos: Los antiguos dorios del siglo XI a.C. que se asientan en la península y dan lugar a la cultura que hoy conocemos como Grecia. 

Estructura sociopolítica que evoluciona de reinado a democracia (las polis) hasta la invasión romana en el 500-400 a.C. y la proclamación de ésta como provincia romana. 

Gobierno: Monarcas - príncipes - tiranos - polis (democracia) 
Esclavismo, cultura del ocio, actitud contemplativa. 

NACIMIENTO DEL ARTE POR EL ARTE (V. página 43, cuadro) 
II.- Cuatro etapas: 
 2000-1000 a.C. Invasión de los dorios 1000-500 a.C. Arcaísmo o etapa arcaica (establecimiento de la democracia) 500-400 a.C. Clasicismo (siglo de Pericles) tiempo de esplendor artístico e intelectual 400 a.C. Helenismo y romanización de Grecia: Tiempos caracterizados por un ilimitado amor por la vida desde una óptica pagana. INICIA EL ESPLENDOR ROMANO. 

III.- Constantes culturales: 
 La razón en contra del idealismo: la imitación de la naturaleza o **mimesis** y la expresión realista. 

 Reproducción de la naturaleza como se ve, y más adelante, como se piensa que debe ser, idealizándola y mejorándola. 

 **Antropocentrismo:** Obra artística centrada en el hombre. Aquí terminan la magiacaza del hombre prehistórico y el dios tótem-animal del egipcio. Incluso las dimensiones buscan el tamaño natural. 

 El arte comienza a ser realmente la expresión del ser humano. 

 El pensamiento filosófico también coloca al pensamiento del hombre por encima de todo, como dice Protágoras "el hombre es la medida de todas las cosas". 

IV.- Disciplinas en la Grecia Clásica: 
A) Arquitectura Todo gira en torno a la "Polis" o ciudad por encima de la vida del individuo Tipos de construcción: La casa: De adobe, sin mayor importancia. Las áreas cívicas: Monumentos públicos y religiosos como las ágoras, la acrópolis y teatros. 

- 11 - 

Fuente: Historia del Arte.- Figueroba.- Mc Graw Hill.- 2004 Materiales: Comienza el uso de la piedra tallada, piedras unidas con grapas metàlicas. Ordenes ("estilos"): Dórico, jónico y corintio. 

Pincipales edificios y construcciones: Templo, acrópolis, santuario, teatro (auditorium, orchestra, paraskenia, estrado o skené), odeón, gimnasio y palestra, ágora, stoa. 

Personaje: Pericles, constructor de los edificios más representativos de la **Acrópolis** ateniense. 

B) Escultura Arcaísmo: Hay tres tipos principales de trabajos escultóricos: 
1. **Xóana:** Estatuas de madera con rigidez e influencia egipcia. 2. **Kouroi:** Estatua de atletas masculinos, realista y con movimiento. Ya sean votivas o funerarias. No son retratos. 

3. **Korai:** Estatuas femeninas bien vestidas, hechas en mármol y ligeramente sonrientes. Su uso todavía se ignora. 

Etapa Clásica: 
Se perfeccionan las formas, se desarrolla la belleza y la imitación de la naturaleza para incluso perfeccionarla, intención de dar sensación de vida a las obras. Aparecen los artistas: 
1. **Mirón:** Discóbolo. El movimiento. 2. **Policleto:** el Doríforo y las proporciones perfectas. El cuerpo humano proporcionado a siete cabezas y dos tercios. El rostro se proporciona tomando en cuenta medidas de la frente, nariz y de nariz al mentón. 

3. **Fidias:** Lo más importante de Fidias es que fue escultor, pintor, orfebre, arquitecto y director de obras en la restauración de la Acrópolis. La belleza de su obra radica en el aire majestuoso y paradivino que tiene sus esculturas. Sus obras principales: el frontòn del Partenón, el Nacimiento de Palas Atenea y la Procesión de las Panateneas. 

4. **Praxiteles (hacia 370-330 a.C.):** Su temática es Olímpica y es el creador de la llamada curva praxiteliana, que arquea ligeramente al cuerpo al apoyarse en algo exterior a él. Figuras esbeltas y largas. Obras: la Venus de Gnido, Apolo Sauróctono y Hermes con Dionisio. 

V.- Disciplinas en la etapa Helenística Considerada un tiempo en el que el culto al placer y la belleza creció en forma desmedida, tiene una determinante influencia del clasicismo, pero éste pierde su carácter estático, su sencillez y moderación, para ser suntuoso y monumental. Tiempo **hedonista** desarrollado por las escuelas filosóficas. Reflejado en abundancia de figuras femeninas desnudas. El **realismo**, calificado de "amargo" hace su aparición más allá de la reproducción de lo perfecto ofreciendo la posibilidad de apreciar nuevos modos de existencia. 

Temática: Niños, ancianos y mujeres con toda su naturalidad. Vida campestre y pastoril. 

- 12 - 

Fuente: Historia del Arte.- Figueroba.- Mc Graw Hill.- 2004 Temas mitológicos tratados con naturalismo y sensualidad. 

Obras principales: 
Victoria de Samotracia Venus del Milo y Laoconte y sus hijos El legado Romano I.- Introducción: 
Bajo la influencia de los etruscos, se crea el imperio romano. La ciudad de Roma se funda en el año 753 a.C. y entonces comienza un crecimiento que no se detuvo sino hasta años después del nacimiento de Jesucristo, cuando comienza a descender. 

II.- Tres etapas: Monarquía. (753 a.C a 509 a.C.). Epoca de fuerte influencia etrusca, es un periodo en el que confluyen numerosas leyendas y relatos incompletos respecto de su origen y evolución. Los fundadores, según la leyenda, fueron los gemelos Rómulo y Remo en el año 753 a.C., hijos de Rea Silvia, una virgen vestal hija de Numitor, rey de la cercana Alba Longa situada en el antiguo Lacio. Otra tradición más antigua remonta la ascendencia de los romanos a los troyanos y a su líder Eneas, cuyo hijo Ascanio o Julo, fue el fundador y primer rey de Alba Longa. El caso es que el primer rey fue Rómulo y durante su reinado sucedieron los episodios del rapto de las sabinas y la guerra contra los sabinos, dirigidos por Tito Tacio, con la consecuente unión de los pueblos latino y sabino. En la fundación de roma, confluyen tres pueblos según la leyenda de Rómulo. Ramnes o ramneses (latinos) Titios o sabinos y Lúceres o etruscos Así que Roma fue creada por una amalgama de latinos, sabinos y etruscos. Primeros reyes: Rómulo (753-715 a.C.) y Numa Pompilio (715-676 o 672 a.C.), a quien se le atribuyó la introducción de muchas costumbres religiosas. 

Republicano.- (509 a.C. al 27 a.C.). Se consolida el poder en la península itálica y a todo lo largo del Mediterráneo. Vencen a Cartago en las guerras púnicas y crece el vasto imperio. Son guerreros antes que nada. Se desarrolla el esclavismo. Notable influencia griega.

Imperial.- ( 30 a.C. aprox. hasta el 476 d.C. en plena decadencia) En esta etapa, también conocida como la *pax romana*, es de grandes contrastes. Tres siglos de gran esplendor con Trajano y Adriano (romanización de buena parte de Europa) Dos siglos de pérdida de importancia frente al cristianismo y decadencia paulatina. Fundación de Constantinopla en el 330 sobre la antigua Bizancio, conversión de Constantino y la consecuente proclama del Edicto de Milán. 

Constantino: En el 312, en la víspera de una batalla contra Majencio, su rival en la península Itálica e hijo de Maximiano, se dice que Flavio Valerio Constantino soñó que se le apareció Cristo y le dijo que grabara las dos primeras letras de su nombre (XP en griego) en los escudos de sus tropas. El día siguiente, la leyenda dice que vio una cruz superpuesta en el sol y las palabras "con esta señal serás el vencedor" (en latín, in hoc signo vinces). 

- 13 - 

Fuente: Historia del Arte.- Figueroba.- Mc Graw Hill.- 2004 Derrotó a Majencio en la batalla del Puente Milvio, cerca de Roma, en octubre de ese año (312). El Senado aclamó al vencedor como salvador del pueblo romano y le tituló primus augustus. Constantino consideró que el Dios cristiano le había proporcionado la victoria, por lo que abandonó sus anteriores creencias paganas. Detuvo la persecución de los cristianos, y Licinio Liciniano, su coemperador, se le unió en la proclamación del Edicto de Milán (313), que ordenó la tolerancia del cristianismo en el Imperio romano y restituyó a la Iglesia los bienes confiscados. 

III.- Constantes culturales: 
Roma absorbe las aportaciones culturales de los otros pueblos a los que conquista: es el conquistador conquistado, lo que lleva a cierto eclecticismo en su estilo. 

Traslado de las obras griegas a Roma, de artistas. Multiplicación de los talleres Influencia de la ornamentación oriental Arquitectura: Desarrollo de Arco, bóveda y cúpula. Escultura: Retrato realista con fin votivo y de culto y decoraciones alegres. 

El arte resultaba condicionado por la política, convertido en medio de comunicación y manifestado, tanto en la arquitectura, por su grandiosidad y compromiso de servir para el disfrute ciudadano o los homenajes como los arcos de triunfo y columnas conmemorativas, como en la escultura, que quería celebrar la figura del jefe político en turno. 

IV.- Disciplinas en Roma: 
Arquitectura Para los romanos, el concepto de arquitectura implicaba construcción de edificios, relojes, máquinas y barcos. 

Tres tipos de edificios públicos: 
1. **Fines defensivos** 2. **Fines de culto** (templos, altares, tumbas) 3. **Fines utilitarios**. (puertos, basìlicas, plazas, silos, cárceles, anfiteatros, auditorios, estadios, hipódromos, termas, cisternas...) 
Nuevos tipos de construcciones 1. **Edificios** de alquiler, con varias plantas. 2. **Basílicas** (edificios de tres naves con planta rectangular, para transacciones comerciales, antecedente de las basìlicas cristianas. 

3. **Anfiteatros** (centros de atacción y divertimento para combate de gladiadores, caza de fieras). 

4. **Termas** (baños, salas de vapor, baños de agua frìa, piscinas, gimnasios, etc.) 5. **Acueductos** (Sistemas de abastecimiento de agua). 

Dos tipos de ciudades:
- 14 - 

Fuente: Historia del Arte.- Figueroba.- Mc Graw Hill.- 2004 1. **Municipia** (Ciudades de carácter agrario. Los romanos vivìan en las afueras. El trazo era de retícula y rigor geométrico). 

2. **Coloniae** (Ciudades de nueva fundación, aliadas de Roma, con status y privilegio romano pleno). 

Nuevas aportaciones arquitectónicas.

1. **Domus**.- Era el alojamiento unifamiliar para familias privilegiadas y muy ricas. 2. **Insulae**.- bloques de viviendas divididas en cinco 3. **Villae**.- Casas de campo, construidas en las afueras, semejante al domus pero con áreas ajardinadas. 

Prioridad de la salubridad: calles pavimentadas, sistema de alcantarillado para eliminar aguas residuales, canalización de aguas, cisternas y desarrollo de incineración y cementerios extramuros. 

Elementos formales de la arquitectura y materiales:
1. Roma republicana: Ladrillo y adobe 2. Roma imperial: mármol 3. Hispania: Barro revestido de piedra. 

El típico muro es de hormigón revestido de mármol. Principales elementos sustentantes: Arcos de de medio punto. Orden principal: una combinación del jónico y el corintio, conocido como compuesto. 

Principales construcciones: 
1. El templo, cuyo mejor ejemplo es el Panteón de Agripa. 2. El anfiteatro (el más famoso es el anfiteatro Flavio, más conocido como el coliseo Romano) 
3. El circo, edificio público destinado a carreras de caballos, simulaciones de batallas y cacerías de fieras. 

4. El Teatro, influenciado por el griego, pero con menos espacio para la orchestra, construido sobre un terreno plano. El público se instala en la cavea o graderío. 

Escultura Retratìstica Representación de toda clase de persona, no sólo de dioses o personajes famosos. Característica principal: Fuerte realismo. El emperador era representado segùn tres formas: 
a. Thoracata (ecuestre) b. Togata (vestido con toga de patricio) c. Apoteósica (semidesnudo) 
Ejemplo más famoso: Estatua ecuestre de Marco Aurelio y retrato de Augusto Relieve Presente en columnas y arcos En los sarcófagos alcanza gran detalle y esquisitez Materiales: piedra y bronce. 

La pintura
- 15 - 

Fuente: Historia del Arte.- Figueroba.- Mc Graw Hill.- 2004 Pintura mural, ccn representaciones paisajísticas, bodegones y escenas de género y retratos de tendencia naturalista. Decoración de las casas familiares semejando arquitectura de columnas y ventanas con efectos de profundidad. 

Mosaico, que ornamenta suelos, paredes y fuentes. Temas geométricos, retratos y temas de cosmovisión o mitológicos. 

La Edad Media I.- ARTE PALEOCRISTIANO Dos etapas: a) Primitiva, de clandestinidad y escaso desarrollo artístico (antes del Edicto de Milán) b) De desarrollo o paleocristiana (siglos IV al VI) Aparece la figura de Jesucristo a partir del año 30 de nuestra era. Dogmas: Trinidad, Encarnación y Redención RASGOS: Persecuciones a Cristianos de los Emperadores Romanos: Decio (249 y 251) y Diocleciano (303 y 305) La presencia de Constantino (Edicto de Milán 313 d.C.) El arte en las catacumbas y Tituli La labor misionera de los Apóstoles La clandestinidad CATACUMBAS: Siglos I al V Son cementerios subterráneos Estructura arquitectónica simple, formada por galerías estrechas situadas en varios pisos. Iconografía de dos tipos: Pagano (El buen pastor, la paloma o Espíritu Santo, etc.) El viejo testamento 
(Personajes bíblicos como Moisés, Noé, Daniel, Jonás, etc.) Rasgos fundamentales: pintura artesana, frontal y sin perspectiva, de imágenes planas: les deja de preocupar la representación física cediendo el turno al simbolismo. 

II.- ETAPA DE LA IGLESIA TRIUNFANTE O PALEOCRISTIANA Tres construcciones principales: Basílica, Martyria y Baptisterios Basílica: * Planta rectangular * Tres a cinco naves de diferente altura y separadas por columnas * Orientada de Oeste a Este (altar hacia Jerusalén) * La nave central tiene dos aguas y una en las laterales Martyria: * Para dar culto a las reliquias de los mártires cristianos * Generalmente son redondos (evocando la imagen del universo) * Constan de una cámara baja cruciforme, donde están las reliquias, rodeadas de una nave circular o poligonal. Baptisterios: * Giran en torno al concepto del sacramento del bautismo, símbolo de ingreso del nuevo cristiano a la iglesia 
- 16 - 

Fuente: Historia del Arte.- Figueroba.- Mc Graw Hill.- 2004 
* Forma circular, con una pila central para el bautismo * Hasta el siglo V solía ser un edificio separado de la iglesia-templo ICONOGRAFÍA DE LA ÉPOCA: · Predominio de la pintura sobre la escultura · Temas: Cristo dando la ley, Cristo entre los apóstoles. · Técnica: el Mosaico, elemento decorativo heredado de los cristianos · Comienzan a elaborarse los manuscritos o libros sagrados "miniados" decorados delicadamente a mano. Se les llama también códices a partir de la sustitución de los antiguos rollos. 

III.- EL ARTE BIZANTINO E ISLÁMICO Antecedentes: División del imperio en dos grandes sectores: Oriente (Lugar del esplendor del Imperio Bizantino) Occidente (Arriban los pueblos germánicos y bárbaros) Influencia del arte Paleocristiano en el bizantino y presencia paulatina del arte de los pueblos bárbaros. Influencia del arte islámico. 

Arte concentrado en el contenido mucho más allá de la forma, que es de importancia menor. El afán por representar la realidad no reaparece sino hasta el renacimiento. La pintura se vuelve evangelizadora y tiene carácter sagrado. A partir del siglo V comienza una corriente contraria a la figuración o "arte figurativo" predominantemente en los temas humanos. Problemas y discusiones conceptuales que redundan en las expresiones: iconoclastas Vs. iconodulos. Arribo de los pueblos bárbaros: Godos, vándalos, alanos y suevos que saquean a Roma y la debilitan. 

 Feudalización del Estado. 

 El arte representa de acuerdo con parámetros romanos. LOS VISIGODOS Se establecieron en la península ibérica y fijaron su capital en Toledo. * Notas definitorias de su arquitectura: - Planta basilical o cruciforme - Arco de herradura - Construcción en piedra - Uso de bóveda de medio cañón LOS FRANCOS Provienen de Holanda y Alemania principalmente. Se les considera el origen del pueblo francés Su primer rey: Clodoveo (principios del siglo VI) Logran una alianza con el Papado al coronar a Carlomagno como nuevo Constantino. 

LAS FORMAS BIZANTINAS El arte bizantino comienza cuando Constantino instala la capital del reino en oriente y nombra a Bizancio como la nueva "Constantinopla". Le corresponden tres etapas: La primera se corresponde con el período Paleocristiano, la segunda supera la crisis iconoclasta con predominio de imágenes o tipología de la Virgen y 
- 17 - 

Fuente: Historia del Arte.- Figueroba.- Mc Graw Hill.- 2004 el cristo Pantócrator y finalmente la tercera o deuterobizantina se extiende por los pueblos eslavos, rumanos y rusos que definen a partir de entonces su identidad hasta la fecha, presente en la iglesia ortodoxa. 

Constantes del arte bizantino: Presencia de la CUPULA, que se vincula con la bóveda celestial. El COLOSALISMO, que manifiesta la exhibición del poder en las grandes dimensiones de los templos. Notorio CONTRASTE entre el interior de gran lujo y el exterior más austerio de las edificaciones. Uso de LADRILLO como material constructivo. IGLESIA de tipología de planta de cruz griega y de planta cuadrada. Iconografía bizantina: Tratan de ofrecer una exposición decorativa de las líneas teológicas. Utilizan fundamentalmente la imagen o figura, con distancia de la realidad. Cristo es representado como el Cristo Pantocrátor. 

Técnicas: Arte musivario (mosaico, como en Roma, pero más brillantes). Decoración de manuscritos y libros. (El arte de los libros miniados). Proliferación de iconos e imágenes poco expresivas, hieráticas. Pintura al fresco. 

Arte Islámico El arte islámico parte de una constante: rechaza la imagen explícita y se inclina más por las formas vegetales y sugeridas, organizadas con geometrismo. La reproducción de la imagen no está bien vista; de ahí que la escultura no haya sido cultivada y sí por el contrario el trabajo en estuco, de gran saturación. La presencia de las imágenes implica el riesgo a ser idolátrico. 

Materiales: Yeso y escayola (para las filigranas de estuco), ladrillo, mampostería, madera y mimbres para biombos y celosías. En esta cultura perviven del arte romano la columna y el pilar. Predomina el estilo corintio pero el cuerpo de la columna tiende a ser más esbelto. 

El ARCO también lo utilizan con abundancia, predominantemente en forma de herradura, como en la mezquita de córdoba. LA DECORACIÓN es geométrica, con pequeños detalles y mosaicos, caligráfica (textos escritos del Corán). Es notoria la presencia del PATIO de varios pisos, comunicado con otros y con decoraciones lujosas y abundante vegetación, donde reservaban a las mujeres en el harén. De todas las construcciones islámicas, la Mezquita es considerada la más original (la más propia) que también es un lugar de reunión para la comunidad. 

IV.- LAS FORMAS ROMÁNICAS 
- 18 - 

Fuente: Historia del Arte.- Figueroba.- Mc Graw Hill.- 2004 El arte románico es el primer arte unificado del mundo cristiano occidental que se desarrolla en los siglos XI y XII llegando en algunas áreas hasta el año 1250. En esos tiempos, el único monumento es la casa de Dios. Tiempos de invasiones bárbaras (normandos y húngaros). Hubo una fuerte lucha entre el poder civil y el papado, donde se concentraba el poder con gran incidencia de los señores feudales. Consolidación de los feudos y su poder. Se generan prácticas como la nicolaísta que consistía en el concubinato o matrimonio de los clérigos. Proliferan las peregrinaciones. Se observa el "terror del año 1000". Los centros de peregrinación más importantes fueron Tierra Santa, Roma y Santiago de Compostela. Proliferan también las cruzadas, expediciones militares llevadas a cabo los cristianos para recuperar los Santos Lugares de manos de los musulmanes. La ciudad románica era una zona amurallada donde destacaban las torres y las puertas. Las calles carecían de pavimentación y agrupaban a las tiendas y talleres. Las casas, en general, eran humildes. Los castillos eran los centros defensivos y económicos, cuya forma está condicionada a la evolución de las armas de guerra, y generalmente son construidos en puntos estratégicos como elevaciones naturales, macizos rocosos. Los monasterios se componen de varias áreas: hospedería, novicios y enfermería. 

LAS IGLESIAS ROMÁNICAS: 
Hay predominio de la masa sobre el vano. Utilizan la piedra como material. Utilizan el arco de medio punto y el vano como integrante de los sistemas de cubierta. La orientación: el ábside esta hacia el Este, símbolo de origen pagano que adquiere el significado de búsqueda y recepción de la Luz, identificada con Dios. 

EL ARTE DE LA IMAGEN EN EL ROMANICO 
Las fuentes de inspiración fueron los textos bíblicos, los evangelios apócrifos, los textos (apologías) de la Patrística y las leyendas hagiográficas y los bestiarios. En el arte románico, el marco es el que determina la forma de la imagen. 

Los conjuntos formales más importantes La Maiestas Domini o majestad del señor La figura de Jesucristo como Dios hecho Hombre, carente de dolor. María la Virgen, vinculada con la tradición bizantina El bestiario. 

LA ESCULTURA ROMÁNICA 
Se adapta a las exigencias del conjunto arquitectónico. Es elitista y didáctica. Es monumental. Estatuas de santos que aparecen adosadas a los pilares del transepto de la catedral de Chartres. Se esculpieron entre 1132 y 1240. Marcan transición entre románico y gótico por ser las posturas más naturalistas. 

- 19 - 

Fuente: Historia del Arte.- Figueroba.- Mc Graw Hill.- 2004 LA PINTURA ROMANICA 
Presenta colores intensos. Imágenes de colores y líneas muy marcados y figuras siempre de frente. Se inspira en las formas bizantinas. El románico se expresa también en la miniatura. Comienza, incipiente, el arte de la vidriera o vitral, que luego se desarrollará abundantemente en el período gótico. 

V.- EL GÓTICO: "EL HOMBRE HACIA DIOS Y DE DIOS AL HOMBRE" 
CONCEPTO Y CRONOLOGIA El Gótico ocupa un periodo que se extiende desde mediados del siglo XII hasta ya casi el siglo XVI, es decir, unos cuatrocientos años. Su delimitación estilística y cronológica presenta una gran dificultad, ya que mientras en algunas áreas se trabaja en coordenadas del Gótico, en otras se trabaja aún con las del Románico, o bien ya se construye en coordenadas del Renacimiento. 

CONTEXTO HISTORICO 
1.- EL ENTORNO HISTÓRICO El Gótico se manifiesta en una sociedad urbana y ya burguesa cuyo entorno es una manifestación de la recuperación económica. 

Desde el punto de vista social se observan: a) Fuerte crecimiento demográfico b) Desarrollo de los gremios c) La humanización del caballero cristiano. 

Políticamente, las monarquías europeas se consolidan y fortalecen, amparadas por el ejército. De este modo, reyes, príncipes y la rica nobleza se convierten en promotores de un arte cortesano fantástico, evasivo y fastuoso. La mayoría de las obras son de carácter religioso y suntuoso. 

2.- ENTORNO FILOSOFICO-CULTURAL LA AFIRMACION DE LA REFORMA CIRTERCIENSE Se produce un cambio cultural progresivo hacia el laicismo y una mayor valoración del hombre, que desembocará en el humanismo renacentista. Esto se fundamenta en el Cister (1098, comunidad religiosa derivada de la orden de San Benito), que criticó profundamente al estilo de vida fastuoso de los monasterios benedictinos. 

VICISITUDES EN EL INTERIOR DE LA CRISTIANDAD El espíritu religioso desarrolla en su interior ciertos síntomas de protesta que se manifiestan tanto en la fundación de sus órdenes, como en la aparición de movimientos calificados de heréticos (herejes). Se constituyen los dominicos y los franciscanos. La cristiandad de occidente entra en una inminente crisis política, teológica y moral… 
ARQUITECTURA CIVIL: LA CIUDAD El crecimiento de las ciudades se debe a causas económicas, culturales, y políticas. Se puede observar en la nueva fisonomía una división interna, un deseo de dotar a la ciudad de una estructura físico-jurídica, interés por los espacios comunitarios 
- 20 - 

Fuente: Historia del Arte.- Figueroba.- Mc Graw Hill.- 2004 
(ayuntamientos), y una evolución de los lugares residenciales (palacios en lugar de castillos). 

ARQUITECTURA RELIGIOSA: LA CATEDRAL La Catedral define la fisonomía de la ciudad Gótica, al grado de que la ciudad trabajaba para la Catedral. 

LA CATEDRAL GÓTICA 
CONTENIDO SIMBOLICO Y ESTETICO 
ELEMENTOS FORMALES EL GÓTICO SEGÚN 
LA NACIONALIDAD 
EL GOTICO A PARTIR DEL SIGLO XV 
Inglaterra. Luz y altura en los edificios; ventanales grandes, unificación espacial y riqueza decorativa. 

Inglaterra: Apego a la estética románica Líneas de estilo francés. División del espacio interno. Torre cuadrada sobre el crucero Bóvedas de abanico España. Influencia francesa y desarrollo de plantas sin nave crucero. 

La Catedral es el centro visual de la ciudad; hacia ella convergen los caminos y las calles. La Catedral Gótica es símbolo de la Iglesia espiritual, y su carácter celestial se resalta mediante la verticalidad, y mediante la concepción de un espacio arquitectónico luminoso y diáfano. 

Gótico clásico (siglo XIII) Pilares y predominio de las vanos Muro de tres niveles Impulso y desarrollo de la verticalidad Menor consideración del espacio interior Carencia de líneas ascendentes Presencia de pintura mural Techumbres de madera Recubrición con materiales suntuosos Fachadas plaqueadas de mármol Inspiración en el Clasicismo Ausencia de arbotantes Alemania: Modelos franceses. Acusada verticalidad Agujas caladas EL ARTE DE LA IMAGEN EN EL GOTICO 
CONTENIDOS IDEOLOGICOS Pensamiento escolástico y franciscano Preocupación por la muerte Influencia del ascenso de la burguesía TEMAS Y FUENTES DE INSPIRACIÓN El Paraíso.- Dios hecho hombre.- La Virgen María.- El santo.- El hombre.- La muerte LA ESCULTURA Materiales: piedras de diversos tipos, para la ingeniería exterior; madera policromada, para imágenes exentas, retablos, sepulcros y sillería de los coros; y mármol y alabastro, en conjuntos sepulcrales y retablos. 

Búsqueda del realismo o "voluntad de realismo" LA PINTURA Vidriería o Vitral Cristal policromado. Cubren grandes áreas y las escenas representadas suelen leerse de arriba abajo. Composición formada por centenares de piezas diminutas unidas por varillas o cañuelas de plomo. 

MINIATURAS Los manuscritos se escribían en los *scriptoria* de los monasterios, pasando después a los ambientes talleres urbanos para ser ilustrados con miniaturas. 

EL FRESCO Y LA TABLA 
- 21 - 

Fuente: Historia del Arte.- Figueroba.- Mc Graw Hill.- 2004 La pintura al fresco es más escasa, sin embargo, la pintura que se puede considerar como propia de la Iglesia se manifestaba en retablos, pintados con la técnica del temple sobre tabla y, más tarde, con óleo. 

Tres momentos importantes: 
EL GOTICO LINEAL, 
LA PINTURA DEL DUECENTO Y DEL TRECENTO ITALIANOS, 
LOS PRIMITIVOS FLAMENCOS 
1.- EL GOTICO LINEAL Primer período de la pintur0a gótica, caracterizado por la producción de miniaturas y vidrieras. 

2.- PINTURA DEL DUECENTO Y DEL TRECENTO ITALIANOS La Escuela de Siena: Se expresa fundamentalmente en la pintura de tabla y el mosaico. 

La Escuela de Florencia Cimabue Giotto di Bondone 3.- GOTICO INTERNACIONAL Características Estilización de todas las formas Gusto muy refinado Temas religiosos imbuidos de ambiente humano Reproducción de objetos anecdóticos de la época Destacan los pintores alemanes como Stefan Lochner, de la escuela de Colonia. 

PRIMITIVOS FLAMENCOS (Flandes) Siglo XV 
Características Innovación Desarrollo de la pintura sobre tabla Minuciosidad y detallismo Introducción del retrato Interés por la reproducción de los objetos de la vida cotidiana Amor al paisaje Naturalismo Pintores más señalados Primera generación (1414-1430) Jan y Hubert van Eyck Van der Weyden Segunda generación (1430-1460) El Bosco
- 22 - 

Fuente: Historia del Arte.- Figueroba.- Mc Graw Hill.- 2004 El Renacimiento ANTECEDENTES El Renacimiento es quizá, si no el más importante, sí el más significativo período de la historia del arte. La palabra "renacimiento" nos remite a dos interpretaciones: a) Etapa cultural "renaciente" en el campo artístico. b) A las manifestaciones artísticas específicamente Florentinas y del siglo XV y XVI El **Primer Renacimiento**: Corresponde al siglo XV y se caracteriza por ser un rescate de la antigüedad. Se le llama también el "cuatroccento" El **Segundo Renacimiento**: corresponde al Siglo XVI y su búsqueda es por hallar lo nuevo por hacer dentro de lo clásico. Se le llama el Cinquecento y entre otros rasgos, comienza a dejar ver algunos atisbos decadentes del manierismo. 

HECHOS HISTÓRICOS Y RASGOS GENERALES DEL RENACIMIENTO: La investigación y el naturalismo en las representaciones.- La influencia del pensamiento de Petrarca, re-fundador del humanismo y antropocentrismo.- La imprenta de Guttenberg, que con su aparición permite la divulgación y el alcance masivo de los conocimientos.- El interés científico por la naturaleza y la aplicación de esta ciencia al arte (el científico-artista llega a su máxima culminación con Leonardo Da Vinci).- Cobra auge la economía capitalista y la reactivación de las ciudades.- Surgimiento de grandes monarquías, en contraposición a los pequeños reinos medievales De lo anterior, se pueden inferir también varias causas: 
La vuelta a la antigüedad (el antropocentrismo se enfrenta al teocentrismo) y el artista comienza a verse como un humanista. Se revalora al artista como individuo: tiene rostro y nombre. Se considera la posibilidad de la existencia del genio: Se admira su capacidad extraordinaria, que lo sitúa por encima de todos los demás artistas. Surgen los mecenas y cobran auge por muy diversas razones.- El arte se comercializa, se vende, se colecciona, se cotiza...- En el aspecto religioso, es el surgimiento de las reacciones en contra de la iglesia: Martin Lutero y Juan Calvino con el pensamiento protestante sacuden a la Iglesia católica. - En reacción opuesta, sobreviene la contrarreforma, que da lugar a dos hechos de interés: el nacimiento de la Compañía de Jesús, basada en los principios de pensamiento y obediencia y el Concilio de Trento, que reorganizó a la iglesia y sentó las bases de su nuevo funcionamiento. 

La Arquitectura del Renacimiento CARACTERISTICAS: Su principal fuente de inspiración es la ANTIGÜEDAD CLÁSICA.- Los artistas tenían a su alcance las ruinas grecorromanas.- Se produce en ella la unión entre la teoría y la praxis. -Existe en el ámbito teórico la realización de planos y proyectos para llegar al "proyecto perfecto" .- lcanza su máxima expresión en la Florencia del siglo XV, con el apoyo económico de los Médicis. 

MATERIALES: Ladrillo y revestido de placas de mármol. - La ciudad renacentista recibe un desarrollo más intelectual que práctico (ver el proyecto de Urbino).- Se desarrollan las villas venecianas y romanas 
- 23 - 

Fuente: Historia del Arte.- Figueroba.- Mc Graw Hill.- 2004 Prolifera la construcción de los palacios: el modelo es el palacio florentino del Quatroccento, aún con influencias del palacete medieval.- La qrLa arquitectura religiosa presenta el uso de la cúpula y la pérdida del simbolismo del gótico y también fachadas almohadilladas y el nuevo orden gigante de los templos. Artistas: Quattrocento: Filippo Bruneleschi (Cúpula del duomo de Florencia) Cinqueccento: Donato Bramante (San Pedro) y Miguel Ángel (culmina la basílica de San Pedro). 

La Escultura del Renacimiento CARACTERISTICAS: Su desarrollo tendrá lugar en Florencia.- Su carácter distintivo será vuelta a la antigüedad.- Capaz de producir placer estético.- Tema: el hombre fundamentalmente desnudo.- Redescubrimiento de la belleza corporal.- Realismo anatómico Retrato realista (vuelta a Grecia y Roma ). 

PRINCIPALES ARTISTAS: SIGLO XV: A) Donatello, autor de estatuas ecuestres y personajes desnudos.- Ej: El David.- B) Verocchio, quien fue maestro de Leonardo, Perugino y Boticelli. Ej: David SIGLO XVI: Miguel Angel: "La imagen ya está contenida en el bloque". Miguel Angel Buonarotti.- Nació en Caprese.- Vivió con una familia de canteros.- Estudió pintura en contra de su padre, escultura en el jardín Medici y fue protegido del mismo Lorenzo de Médici.- Entre otras cosas, llega a disectar cuerpos para estudiar anatomía humana. Obras de su juventud: **El David, la Piedad y el Baco.-** El Papa Julio II le encargó su tumba ("El Moisés"), regresó a Roma y allí hizo la Basílica de San Pedro y le encargan la decoración de la Capilla Sixtina.- Murió en 1564 Pintura del Renacimiento a)Cuattrocento: Querían imitar a la naturaleza, con tres recursos: Profundidad, Expresividad y Movimiento. Dominaron el espacio, con un nuevo sistema de proporción, que concibió por primera vez el término canon y la perspectiva, dominando el punto de fuga. Nacieron los centros de producción o talleres: Siglo XV en Florencia y en el XVI en Roma y Venecia. **Temática**: Religiosa (pero más humanizada), El retrato y la Mitología (allí estaba la vuelta a la antigüedad de Grecia y Roma)**Técnicas**: Fresco, temple y óleo; esta última la más común de las tres. Principales artistas del Cuatroccento: 1- Masaccio, iniciador del renacimiento. Obra: "La Trinidad" 2.- Fra Angélico, escolástico y humanista en cuyo trabajo delicado abundan los acabados en oro. Obra: "La Anunciación" 3.- Andrea del Castagno. Obra: el Abside de San Zacarías 4.- Sandro Boticelli: Importante autor, representativo de la transición entre el siglo XV y el XVI. Sus obras están llenas de gran belleza poética, sus personajes son etéreos y voluptuosos, con rostros alargados y ondulantes cabelleras. Generalmente son de inspiración mitológica: "El nacimiento de Venus" y "La primavera". 

Principales artistas del Cinquecento: Esplendor: Siglo XV Florencia y Siglo XVI Roma Más allá de la belleza del quatroccento, el cinquecento busca equilibrio, moderación y armonía. También llamado "Alto Renacimiento" Escuelas florecientes y principales exponentes: 
- 24 - 

Fuente: Historia del Arte.- Figueroba.- Mc Graw Hill.- 2004 Florentina Romana: Leonardo da Vinci, Rafael y Miguel Angel Buonarotti Veneciana: Tiziano Al **exterior** de Italia: Alberto Durero (Alemania) 
Leonardo Da Vinci: Hombre del renacimiento por excelencia, Nació en Toscana, en Vinci. Practicó la experimentación y sostuvo que el arte debe conocer el mundo visible y la misión del artista es alcanzar la belleza. Da Vinci practicó el famoso "Sfumato" o difuminado, identificado como un "espesor transparente" de la naturaleza. Su protagonista es el hombre. Obra principal: La Virgen de las Rocas.- La Última Cena.- La Gioconda. 

Rafael Sanzio.- Nació en Urbino .-Su obra se caracteriza por la belleza natural de sus personajes.-Una de sus obras más conocidas es "La Escuela de Atenas" (1510-1511) uno de los frescos que Rafael pintó para decorar las estancias del Vaticano y que marca la madurez artística alcanzada durante sus años en Roma (1508-1520). En él aparecen Platón y Aristóteles (centro) así como otros filósofos y eruditos griegos. Está considerado como una obra maestra de la perspectiva y de la expresión de los ideales artísticos del renacimiento. 

Miguel Angel: Principalmente fue escultor y arquitecto.- Su pintura tiene la fuerza de la escultura: tal parecen esculturas pintadas, en una obra minuciosa y detallada, mezcla de idealismo y rebeldía.**Obra principal**: El fresco de la Capilla Sixtina.- a) Techo (Relata desde la Creación hasta la pérdida del Paraíso).- b) Fondo (El Juicio Final) Miguel Ángel pintó el Juicio Final (1536-1541) en la pared del altar de la Capilla Sixtina 20 años después que los frescos del techo. En esta visión apocalíptica del Día del Juicio Final, Cristo aparece flanqueado por las almas salvadas, que ascienden por su derecha, y las condenadas que descienden por su izquierda. 

Escuela Veneciana: TIZIANO Y VERONÉS.- Tiziano: Realizó retratos, temas religiosos y mitológicos. Ejemplo: "Felipe II" .- Veronés: Se identificó con la ostentosa sociedad veneciana del siglo XVI. Ejemplo: "Cristo ante los doctores" El Renacimiento al exterior de Italia En el S. XVI, en Alemania: **Alberto Durero .-** Trabajó las proporciones del cuerpo humano, trabajó la pintura y grabado y abordó temas religiosos, autorretratos, grabados, etc. .- Ejemplos: Autorretrato, Adán y Eva Manierismo Antecedentes: Crisis del optimismo renacentista.- Muerte de los genios (sólo quedaba el viejo Miguel Angel, quien moriría poco después).- Decaía el ideal clàsico del renacimiento.- Se vivía un tiempo de angustia y tensión, falta de confianza en el mundo.- Al manierismo se le ha llamado un "amaneramiento" estilístico, imitación, etc : "maniera" como "manera" y por lo tanto, un período decadente. Sin embargo mejor es que sea considerado un estilo de tensión entre lo natural y lo artificial. El manierismo, en conclusión, toma temas clásicos renacentistas, los manipula y transforma, dejando la forma y prefiriendo el color, conservando sin embargo algunas pautas del renacimiento, como la prioridad de la figura humana A) Arquitectura Manierista: Rechaza elementos clásicos.- Es más decorativa.- Se toma libertades plásticas.- Tiene preocupación urbanística.- Prevee una nueva concepción del espacio. Autor: el italiano Andrea Palladio, autor de villas y palacetes urbanos como la "Villa Rotonda". 

- 25 - 

Fuente: Historia del Arte.- Figueroba.- Mc Graw Hill.- 2004 B) Escultura Manierista del siglo XVI.- Caracterizada por tener formas ornamentales y sinuosas que buscan el desequilibrio. Autores: **Benvenuto Cellini**.- Escultor de formas refinadas, sinuosas y antinaturales. Obras: Perseo .- **Giambologna** (Juan de Bolonia), fue el más prolífico del manierismo. Obra: El rapto de las Sabinas. 

C) Pintura Manierista.- Es la expresión o técnica en la que más destaca el movimiento manierista. -Características: Cuadros densos y "estereotipados" con figuras apretadas entre sí y acumulación de objetos en el llamado "horror vacui" u horror al vacìo. Figuras alargadas (como en la escultura).- Temas experimentales.- Composiciones desde ángulos diagonales.- Tonos fríos. Autores: Tintoretto, Giuseppe Arcimboldo.- Tintoretto (Siglo XVI) Veneciano de trazo monumental, grandes contrastes de luz y sombra, representaciones dramáticas y atormentadas. Obra: "La Ultima Cena". Giuseppe Arcimboldo: (c. 1530-1593). Sus grotescas composiciones alegóricas parecen anunciar el arte surrealista del siglo XX. Inventó un estilo de retrato en el que los rostros estaban compuestos por agrupaciones de animales, flores, frutas y toda clase de objetos. Algunos son retratos satíricos de personajes de la corte y otros son retratos alegóricos. Sus obras fueron consideradas piezas curiosas populares y no adquirieron su justo valor artístico hasta que los surrealistas redescubrieron el juego visual. Sus obras fueron también fuente de inspiración de Salvador Dalí. 

D) El Manierismo Español. 

ARQUITECTURA.- Destaca el trabajo de Juan Bautista de Toledo y Juan de Herrera, arquitectos autores del Real Monasterio de El Escorial, el proyecto más importante de Felipe II. Datos del Real Monasterio: Tuvo tres usos distintos: fue residencia real, monasterio jerónimo y panteón de los Habsburgo.- Estaba dividido en cuatro partes: Iglesia, palacio, biblioteca y convento. La belleza del edificio consiste en su desnudez arquitectónica y ausencia de ostentación. Era el "retiro espiritual del soberano". PINTURA: EL GRECO.- Nacido en Grecia, encontró su época de oro en España y vive principalmente en Toledo. Su obra pasa de tener cromatismos cálidaos y perosonajes de figura fornida o retratos, a figuras alargadas y estilizadas, la desaparición de los fondos de paisaje, composición de cielos oníricos y fantasmagóricos, figuras más alargadas y una gama cromática fría (con azules y grises). Sus obras están llenas de figuras pintadas, que llenan en su totalidad el espacio. Temas: Religioso, retratos.- Obras: La dama del Armiño, El entierro del conde de Orgaz y El caballero de la mano en el pecho. El entierro del Conde de Orgaz.- (1586) Iglesia de Santo Tomé de Toledo. Muestra el momento en que san Esteban y san Agustín introducen en su tumba (actualmente justo debajo del cuadro) a ese noble toledano del siglo XIV. En la parte superior el alma del conde asciende al paraíso poblado de ángeles, santos y personajes de la política de la época. 

El Barroco ANTECEDENTES: Crisis del Renacimiento, algo de retorno a la espiritualidad.- Estilo teatral y persuasivo.- Tiempos de éxito de la inquisición, auge de los Jesuitas (1537).- La contrarreforma y el concilio de Trento hacen a la iglesia católica tener más fuerza y promover más construcción de iglesias. A su vez, hay reyes como Luis XIV convertidos en "majestades" que promueven el arte civil, el mejor ejemplo es el Palacio de Versalles. El término "Barroco" ha sido considerado "irregularidad" "exceso", "decadencia" o "contrarreforma".- El Barroco es un tiempo teatral, en el cual la pintura busca más el color que la línea para acentuar las sensaciones y en la arquitectura y escultura es espectacular y rebuscada. 

Arquitectura barroca 
- 26 - 

Fuente: Historia del Arte.- Figueroba.- Mc Graw Hill.- 2004 ARQUITECTURA BARROCA: Siglo XVII al Siglo XVIII Características: Movimiento, grandiosidad en el espacio visual.- Surge en Italia y luego continúa en España y Flandes (Holanda) y finalmente se desarrolla en muchos focos: Italia, España, Francia, Inglaterra y Europa Central. Se desarrolla en tres aspectos: Arquitectura Religiosa, Arquitectura Civil y Urbanismo. Este estilo es el que llega a México, Brasil y Argentina. En nuestro país el mejor ejemplo es la Iglesia de Santo Domingo, en Oaxaca. Manifestaciones de la arquitectura barroca: Religiosa: Interiores complicados.- Fachadas colosales con elementos superpuestos Desarrollo de la sorpresa con pinturas y arquitecturas fingidas Civil: Palacetes ajardinados, suma de palacio y villa campestre y Espléndidos palacios como Versalles.- Urbanismo: Busqueda de perspectiva.- Concepto de conjunto arquitectónico.- La "calle principal" recta: La avenida.- Retícula (trazo cuadriculado).- Desarrollo del concepto de plaza o zona residencial. Arquitectos y obras: 1.- Italia: a) S. XVII, Gian Lorenzo Bernini. Obra: La Plaza de San Pedro b) S. XVIII Roma- Nicola Salvi .- Obra: La fontana di Trevi. 2.- Francia: Iglesia de la Sorbona .- Palacio de Versalles.- (Luis XIV se muda allí con toda su corte, desde París, a vivir en un mundo irreal).- Áreas destacadas del Palacio de Versalles: Fachada que da a los jardines, Capilla y Galería de los espejos. 3.- España: S. XVII- XVIII, los Churriguera.- Estilo que concedía más importancia a la decoración que a los elementos de estructura. Muestra influencia hispanoárabe y del flamígero y plateresco. Muestra ciertos excesos ornamentales. 

Escultura La escultura barroca se caracteriza por ser grandiosa y monumentalista, utiliza mármol de colores, bronce y madera policromada (pintada de colores). La temática es generalmente pasional, trágica, religiosa o relacionada con la muerte. Esto quiere decir que el arte barroco, en contraposición a la libertad librepensadora del renacimiento, ya agotada como novedad (ya no era "moda") en el manierismo, propone nuevos temas que lleguen a los sentidos, haciendo un poco caso omiso a la estética purista, las obras se vuelven más teatrales, y sin caer en la vulgaridad, se vuelven más exageradas y obvias. a) Italia.- Gian Lorenzo Bernini: La escultura de Bernini está principalmente inspirada en temas religiosos. Su obra tiene gran proyección espacial, noción escenográfica, misticismo en sus visiones celestiales, figuras "serpentinas", que toman casi cualquier forma imaginable. Dio especial relevancia a la escultura funeraria. Obras: Apolo y Dafne.- La cátedra de San Pedro.- El éxtasis de Santa Teresa b) Francia.- La caracteriza una escultura civil y aristocrática. Utilizan mármol para hacer retratos y mausoleos, abordando temas mitológicos. c) España.- La escultura española es fundamentalmente la llamada "imaginería" o talla de imágenes religiosas, para iglesias y retablos. Temas principales: el Cristólogico, el Mariano y el Santoral. Las obras de la escultura barroca española son especialmente realistas y dramáticas, realizadas en madera policromada. Autores.- Gregorio Fernández, Pedro de Mena. 

Pintura a) Italia.- Caravaggio y el Tenebrismo..- La obra de Caravaggio se caracteriza por su naturaleza violenta y tormentosa. Su obra ignora el paisaje y revalora la naturaleza muerta. 

Caravaggio pintó también episodios evangélicos inspirados en la realidad circundante. La técnica del tenebrismo consiste en que el cuadro muestra una sola entrada de luz por medio de un rayo para resaltar lo que encuentra a su paso. Ejemplos: "La cena de Emaús".- y "El joven Baco enfermo". 

- 27 - 

Fuente: Historia del Arte.- Figueroba.- Mc Graw Hill.- 2004 También fue muy importante el llamado "Barroco decorativo" que se utilizó para ornamentar bóvedas y muros. b) Flandes.- En los paises bajos, la vida se caracteriza por el bullicio y la animación. Bruselas es convertida en el refugio de señores franceses que huyeron de las guerras entre calvinists y católicos. Aquí se gesta la cuna de la pintura flamenca. Pedro Pablo Rubens: Fue el artista pictórico más importante. Fue un artista bien educado, culto y amante de las fiestas, el amor y la belleza. Temas principales: Religiosos, mitológicos, retrato y paisaje. Entre sus alumnos, destaca Van Dyck. Ejemplos de obra de Rubens: "Las tres gracias" y "El descendimiento" Van Dyck.- Absorbe y resalta los aspectos más refinados y sutiles de su maestro Rubens. Se vuelve especialista en el retrato cortesano. Ejemplo: Retrato de Carlos I de Inglaterra c) Holanda.- Gracias a la posición Calvinista que limita lo religioso a una vuelta a la lectura de la Biblia y a la reflexión personal, lo que la hace más intimista, la pintura holandesa y el arte holandés en general pudieron tener mayor libertad en la interpretación de temas. De esta manera, el pintor holandés, en general, prestará más atención a lo cotidiano para representar la vida diaria, el paisaje que lo rodea y el rostro humano, a través del retrato, que se desarrolló generosamente en este país. Rembrandt.- Fue conocido como el "pintor de la luz" ya que logró para sus obras una luminosidad peculiar, que envuelve a los personajes y los aísla del espectador, una luz nocturna que parte del tenebrismo y envuelve con un brillo único solamente los rincones donde el pintor quiso. Temas fundamentales: Pintura religiosa, retratos, autorretratos, pintura religiosa y temas populares. Ejemplos.- La lección de Anatomía, El regreso del hijo pródigo, Autorretratos. Vermeer.- Creador y máximo cultivador del llamado "cuadro de interior", expresión de la vida burguesa. Lo caracterizan sus composiciones, minuciosas y detalladas, en las que retrata a personajes ocupados en labores cotidianas.- Ejemplos.- La encajera, El astrónomo. d) España.- En españa, la pintura del siglo XVII adquiere un carácter propio, distinto a las demás escuelas. Los principales focos fueron Madrid y Sevilla. Entre los principales artistas españoles, destacan José de Ribera, Zurbarán y sobre todo... Diego Velázquez. 

Diego Rodríguez de Silva Velázquez. Uno de los más grandes genios de la pintura universal, fue conocido como "el pintor de la corte". Sus principales temas fueron los ambientes cortesanos, los retratos, los bufones, la mitología, el paisaje, la historia y la religión. Ejemplos.- El bufón don Sebastián de Mora, Las Meninas. .- El príncipe Baltasar Carlos. 

El Rococó El estilo al que llamamos Rococó es una creación francesa desarrollada durante los reinados de Luis XV y Luis XVI. Lo caracterizan su ligereza, fragilidad y gracia (quizá también la superficialidad) que se contraponen a la profundidad y seriedad del barroco. El elemento decorativo más sobresaliente de esta corriente es la "rocaille" elemento asimétrico, combinación de vegetal y mineral, que invade la arquitectura y las artes decorativas. En medio del auge de la burguesía, el Rococó pertenece a una nueva sociedad en la cual la mujer adquiere un gran protagonismo, con el ejemplo más significativo de Madame Pompadour. El rococó destacó mucho más en los salones elegantes, en un momento de gran apogeo para Francia, en el que fue el arte expresado en los interiores decorativos; principalmente en las expresiones mobiliarias, las expresiones decorativas y utilitarias en cerámica, cristal y orfebrería; en la tapicería, así como en la pintura y escultura. En escultura, el más famoso artista fue **Pigalle**, escultor de la corte al servicio de Madame Pompadour. Escultor de gusto teatral, es autor de "El niño de la jaula" y el "Mausoleo del mariscal d'Harcourt". 

- 28 - 

Fuente: Historia del Arte.- Figueroba.- Mc Graw Hill.- 2004 En la pintura, el mayor de la época es el pintor Fragonard, artista versátil, caracterizado por su amor a la naturaleza y el paisaje y su pincelada rápida y cremosa. Obra: El Columpio. 

Neoclásico El rococó llegó a un exceso tal de superficialidad y decoración, que como de costumbre, las cosas tuvieron que llegar a un punto de cansancio y de nuevo, comenzar a cambiar. Lo más importante de este movimiento es que surge en el seno de la crisis del rococó y cobra esplendor en plena Revolución Francesa e imperio napoleónico. ¿Por qué? por un lado surge como una respuesta al absolutismo de la corte; por el otro, el descubrimiento de las ciudades de Herculano (1738) y Pompeya (1748), sepultadas más de mil años atrás por el volcán Vesubio, vuelven a poner "de moda" a los valores griegos y romanos, ya sea como modelos de estética o como normas racionales: "hay que pensar como los griegos, hay que luchar como los romanos". Incluso, mucha gente comenzó a considerar indispensable viajar a Roma para tener contacto directo con los testimonios de la antigüedad. 

La Arquitectura.- Europa se **llenó de casas de campo o "villas" y edificios** urbanos de tipo palaciego. Esta arquitectura que retoma las formas clásicas (columnas dóricas, jónicas o corintias, frontones como el del Partenón, remates cupulares, etc.) se centró más en los edificios laicos que en los religiosos, como museos, bibliotecas, teatros, paseos públicos, etc. Es decir, cansados de tanto dramatismo, tantos santos llagados y vírgenes llorosas que llenaron el barroco y también hartos de florituras y figuraciones retorcidas del rococó, el Neoclásico tenía que proponer de nuevo serenidad e intelectualidad en sus formas. 

A) Francia: Chalgrin: Arco del Triunfo de L'Etoile.- B) España: Sabatini: La Puerta de Alcalá.- Villanueva: El Museo del Prado.- C) Estados Unidos: El Capitolio.- La Casa Blanca.- D) Mérida.- El Palacio Cantón (Museo Regional de Antropología e Historia).- El Peón Contreras.- El Ateneo Peninsular (Edificio del Museo Macay). 

La Escultura.- Con ideología semejante a la arquitectónica, se caracteriza por el uso del mármol blanco como material más puro, por la vuelta a la antigüedad de los modelos de belleza, más intelectuales y distantes anímicamente del espectador, con lo que se eliminan emociones y dramatismos en las figuras, así como movimientos complejos o figuras en acción. Autor: Antonio Canova, el mejor ejemplo del neoclasicismo. Veneciano de nacimiento, pasa en Roma la mayor parte de su vida. Obra: Paulina Bonaparte.- Napoleón.- Psique La Pintura.- La pintura del Neoclásico está centrada en la educación proveniente de las academias. Al no haber muchos modelos griegos ni romanos para imitar, los pintores del neoclásico optan por las composiciones sencillas, centradas y sin contrstes lumínicos, para lograr figuras que finalmente resultan tratadas como si fueran esculturas. De esta manera, el pintor neoclásico prefiere el dibujo al color, al que considera como algo superficial y/o secundario. Autores: Jacques Louis David: Coronación de Napoleón y Josefina Jean Auguste Ingres: La bañista.- El baño turco 
- 29 - 

Fuente: Historia del Arte.- Figueroba.- Mc Graw Hill.- 2004 El caso de Francisco de Goya 
¿Del rococó al expresionismo? 

Francisco de Goya nace en Zaragoza (España) y hereda la pintura de su padre, dorador de profesión. Rechazado de la Academia de Bellas Artes de San Fernando, logró entrar hasta 1780. Sin duda, Goya es un pintor especialmente distinto, creador de retratos, criaturas monstruosas, fantasmas y muchos temas más. Goya entra al arte español en el momento de transición entre el Neoclasicismo y el Romanticismo. Sin embargo su creatividad es más visionaria y abarca varios géneros a la vez. Es un importante predecesor del impresionismo. Clasificación de sus trabajos pictóricos: Temas costumbristas, reflejados en la indumentaria. Representaciones festivas, plasmadas en fiestas, juegos, bailes y corridas de toros. Momentos de dolor, como protestas y tragedias del pueblo, etc. Retratos (hizo una abundantísima serie, principalmente de la nobleza y la familia real en particular).- Temática política y social. - Expresión de sus propios sentimientos (destacan sus cuadros que forman parte de la llamada "Serie de la quinta del Sordo" o simplemente "Serie Negra" de Goya, oscura y macabra, llena de seres extraños como brujas, parcas, viejos beatos, borrachos, seres mitológicos, etc. muchos de ellos inspirados en la mente de Goya a partir de las visitas que hizo a manicomios, cementerios y hospitales de apestados. Los temas de Goya como grabador: Caprichos .- Crítica social con humor .- Desastres.- Imágenes de la guerra.- Tauromaquia Los disparates.- (proverbios o sueños). En general, la pintura de los siglos XIX y XX, con todas sus escuelas y tendencias tiene en Goya su fuente de inspiración, en temas, técnica, estilo, compromiso y concepción del mundo. Las principales aportaciones de este pintor al arte de hoy es el recurso de la mancha pictórica, el libre manejo del color, el dibujo rápido, la variedad técnica y temática y a libertad creativa. Ejemplos de su trabajo: El Quitasol.- La Familia de Carlos IV.- la maja desnuda y La maja vestida.- Los fusilamientos del tres de mayo.- Retrato de la duquesa de Alba. 

Romanticismo y Realismo 
 (Se acaban los tiempos antiguos) 
El Romanticismo Pasado el período de la intelectualidad neoclásica (revolucionaria francesa), el romanticismo comenzó a darse paulatinamente, convertido en el movimiento de las jóvenes generaciones que buscaban cambiar el mundo de los conservadores, intelectuales en extremo y herederos de la rigidez neoclásica. En expresión, el romanticismo se caracteriza por llevar consigo la expresión del sentimiento: pasión amorosa, religión y muerte. En el arte visual hay una recuperación del colorido como recurso, hay gran proliferación de escuelas y abundancia de temas históricos o incluso representación de desastres. Por el contrario, la arquitectura pierde importancia por ser portadora de los valores del pasado. Principales pintores del romanticismo europeo: Gericault.- Predilección por grandes contrastes y compromiso con los temas del momento. .- Obra: La balsa de Medusa Delacroix.- Pintó temas exóticos, con denuncia, literarios y de compromiso revolucionario. Estos últimos son los que más han trascendido, principalmente por su cuadro "La libertad guiando al pueblo". 

- 30 - 

Fuente: Historia del Arte.- Figueroba.- Mc Graw Hill.- 2004 La pintura de paisaje.- Un tema importante de la pintura romántica fue el paisaje, que permitió abrir camino hacia el muy paisajista impresionismo y también (especialmente a los ingleses) permitió encontrar una expresión no política para llevar al lienzo. John Constable (Inglaterra).- Sus paisajes son agradables y sencillos. Su técnica es de pequeñas manchas y trazos superpuestos. Calificado como autor de "pinceladas burdas y rudas" por los puristas neoclásicos, fue en realidad uno de tantos visionarios, predecesores del impresionismo. Camile Corot (Francia).- Pretende crear con su obra un mundo de belleza, serenidad y equilibrio, ajeno a todas las doctrinas. Además de paisajes, pinta retratos, en los que aflora su preocupación por la luz, el intimismo y la variedad de los tonos. 

El Realismo Fue un movimiento caracterizado por querer representar objetivamente la realidad, enfrentándose, como el romanticismo, a la tendencia neoclásica. Caracteriza al realismo su representación de los temas "feos", aunque incomoden, su contemporaneidad o vigencia, su compromiso social y su variedad. Autores: **Courbet.-** Clásico en su tradición en cuando a técnica y color, marca su estilo con los temas que presenta, inspirado en los acontecimientos revolucionarios de 1848. Ej: El taller Millet.- Con un gran sentimiento por la naturaleza, fue tachado de "socialista" dados su origen humilde y el pintar al campesinado. Ej: El Angelus, Las Espigadoras Daumier.- Se desarrolla gracias al auge de la prensa política Ej: La lavandera. 

El Impresionismo Se identifica como impresionismo a la separación de un grupo de pintores que toma el nombre de un cuadro de Monet con este nombre ("Impresión"). El impresionismo es resultado de algunas circunstancias históricas como la generalización y proliferación de la fotografía, que obliga a la pintura a buscar diferentes vías de expresión, a la existencia de la luz artificial, a la elaboración de un nuevo método de mirar y contemplar la obra de arte y la naturaleza, sumados a la incomprensión social: de entonces a la fecha ha quedado la imagen del artista excéntrico, incomprendido y "rebelde". La pintura impresionista tiene la particularidad del cómo capta la luz , mediante toques fragmentados de color, heredados de Velázquez y Goya.. Además es realista, en el sentido de que capta momentos auténticos de cada día, con sus recursos de iluminación, ya que los pintores huían del taller y el estudio y salían a pintar la naturaleza in situ. Con respecto a los recursos de color, el ojo impresionista es el más avanzado, aquel que ha copiado y reproducido las combinaciones de matices más complicadas que se conocen: no hay claroscuros ni contrastes violentos, sino toda la obra es un entretejido de tonalidades luminosas. Además los artistas del impresionismo generan grupo: son amigos que luchan por ideales estéticos, que se reunen en cafés y celebran tertulias, que pintan y trabajan juntos y generan nuevas ideas, luchan y trabajan, cada uno con su estilo diferente. Los artistas del impresionismo: Edouard Manet: Fue el iniciador del cambio, con su pincelada suelta de grueso trazo con la que dibuja y perfila. Al mismo tiempo, recurre a algunos temas del pasado, como las venus helenísticas y los aterriza. Ejemplos: "El desayuno en la hierba", "La Olympia", Edgar Degas: Su formación académica se traduce en una gran pasión por el dibujo. Pintó muchos temas , casi siempre de interiores, destacando entre ellos los caballos, las mujeres del pueblo, el ballet y los desnudos. 

- 31 - 

Fuente: Historia del Arte.- Figueroba.- Mc Graw Hill.- 2004 Ejemplos: "El ajenjo", "El ensayo" y "Mujer secándose los pies". 

Claude Monet: Pintor impresionista por excelencia, fue experto en el manejo de las variaciones de luz a lo largo del día . Así, pintó sesiones enteras de la Catedral de Rouen, de la estación parisina de San Lázaro y las Ninfas del Jardín del agua. Ejemplos: Las regatas de Argenteuil, La catedral de Rouen. Pierre-Auguste Renoir: Pinta a las figuras como si fueran el paisaje mismo. Es el pintor de la alegría del ambiente parisino. Señalado por algunos como "superficial y vano", él sostiene su ideal de alebrìa y belleza. Sus temas principales fueron las escenas de la vida urbana, los remeros y las bañistas. Ejemplos: El Moulin de la Galette, Grandes Bañistas. Alfred Sisley: Con el paisaje como emblema, es un exquisito representante del impresionismo paisajista. Camille Pissarro: También paisajista, se especializó en el ambiente rústico y de la campiña. Trabajó directamente del natural. Georges Seurat:Es un autor que cambió la manera de pintar, al sustituir la pincelada larga por pequeños toques o "puntos" de colores puros. Así, Seurat marcó el período puntillista o "divisionista" del impresionismo, con esta técnica, más intelectual que el impresionismo, deliberadamente estudiada. Ejemplo: "Domingo por la tarde en la Gran Jatte", "El Circo". 

EL POSTIMPRESIONISMO
Paul Cézanne: Cambia por completo el estilo impresionista al proponer motivos más "organizados" y encaminados al expresionismo. Pinta figuras urbanas, bañistas y paisajes.Ejemplos: "Los jugadores de cartas". Henri de Tolouse-Lautrec.- Atormentado y complejo, físicamente disminuído, este joven rico francés vertió su frustración como jinete en su expresión plástica. Henri va más allá de las sensaciones ópticas del impresionismo, al captar los aspectos psicológicos del mundo que ve a través de su trabajo. Sus temas principales, además de los retratos, reflejan el mundo en el que vivió: prostíbulos, cabarets y el bajo mundo de París. Además, sentó las bases de los carteles que posteriormente se internacionalizaron. Obra: "En el Moulin Rouge", "Retrato de Jane Avril" y "La Toilette". Vincent Van Gogh.- Fue uno de los grandes genios del postimpresionismo, camino al expresionismo. Su existencia triste y caótica debido a su locura, se expresa en su obra, principalmente en sus autorretratos, que tuvo que hacer "a falta de modelo". Pintor de pincelada gruesa y nerviosa, es cada vez más quebrada y sinuosa debido a su perturbación psicológica. Utilizó colores intensos y brillantes. También, Van Gogh es el ejemplo de la vida bohemia y paupérrima de muchos artistas, ya que jamás logró vender un cuadro en su vida: se limitó a cambiarlos por comida y más materiales para pintar. Ejemplos: Autorretratos, Los girasoles Paul Gauguin. Un día tomó la decisión de liberarse del impresionismo, por eso se marchó a la isla Martinica donde viviò durante un buen tiempo. Su inspiración fueron los temas rústicos, mujeres tahitianas y otros motivos que transformaron el concepto de espacio en el entonces moderno concepto de arte. Ejemplo: El Cristo Amarillo, Mujeres de Tahití Augusto Rodìn: Rechazado y criticado por sus contemporáneos, Rodín fue un gran innovador por la introducción en su plástica de la modulación de los planos, el facetado de los perfiles y la expresión abocetda de los rostros. Ejemplos: Balzac, El Beso, El Pensador y Los burgueses de Calais. 

- 32 - 

Fuente: Historia del Arte.- Figueroba.- Mc Graw Hill.- 2004 Arquitectura del siglo XIX 
EL HISTORICISMO.- Es un retorno al pasado, a fin de encontrar de nuevo el equilibiro perdido. Esta renovación se dividió en diversos "neos" como *neogótico*, nerorromano, neoindio o neoegipcio. Sin embargo cualquiera de estas formasa tenía que adaptarse a lo más importante: la función y utilidad de los edificios. El más significativo de todos los estilos renovados fue precisamente el neogótico, dado que sus características facilitaban su adaptación a los materiales y requerimientos de los tiempos, y por su exaltación de la fantasía y las formas históricas medioevales y la religiosidad de otra época. 

LA ARQUITECTURA DE LOS NUEVOS MATERIALES: EL HIERRO.- Las necesidades de los tiempos, el crecimiento de la población y las innovaciones tecnológicos, pronto llevaron al hierro a ser utilizado en la arquitectura, originalmente por ser necesario y después por una nueva y naciente percepción estética. Puentes y torres, palacios de cristal, teatros, plazas de toros, estaciones de ferrocarril, bibliotecas, mercados y mobiliario urbano (farolas, barandas, postes, marquesinas, quioscos, etc.) comienzan a ser hechos de hierro y a permitir paso a este material que llegó para quedarse. 

LAS EXPOSICIONES UNIVERSALES (LA TORRE EIFFEL) Desde el siglo XIX, las exposiciones universales son eventos internacionales concebidos como escaparates para dar a conocer los adelantos de las artes, comercio e industria. En el 2000 la sede fue Hannover (Alemania) y una de las màs famosas de los últimos años fue la de Sevilla, en 1992. Uso de materiales prefabricados, creación de impresionantes pabellones desmontables y la temporalidad de estas exposiciones fue su característica fundamental. Así, fueron construidas algunas maravillas como el Crystal Palace hecho especialmente para la exposición de Londres de 1851 y luego desmontarse. Su extensión fue de 563 metros de largo por 124 de ancho. Sin embargo, lo que más huella ha dejado, sin duda, fue la Torre Eiffel, obra del ingeniero francés Gustave Eiffel, quien la construyó en 1867. Construida para la exposición universal de 1889 fue criticada y señalada como un adefesio; sin embargo, en la actualidad no se puede concebir París sin su presencia. Por supuesto que en este caso no fue desmontada tras la exposición, sino heredada a la ciudad como un testimonio del cambio de los tiempos. 

LA ESCUELA DE CHICAGO.- En Estados Unidos, el panorama es diferente al de Europa. Entre 1870 y 1900 se crea la Escuela de Chicago que desarrolla un nuevo tipo de edificio: el rascacielos, a fin de aprovechar los espacios al máximo, creciendo "hacia arriba". Entre otras consecuencias de la creación de este tipo de edificios, se encuentran el invento del ascensor, la eliminación de la madera, y la incorporación de grandes ventanales a las fachadas, para dar luminosidad. Finalmente, otro hecho importante fue que los ingenieros comenzaron a convertirse en los responsables de la construcción, y no así los arquitectos, como antes. 

EL MODERNISMO: Este fue un estilo arquitectónico que se desarrolló a fines del siglo ppdo. y principios de éste. En Francia recibió el nombre de Art Nouveau y su principal función fue decorativa, por haberse aplicado principalmente en trabajos en vidrio, cerámica, joyería, grabado y cartel, 
- 33 - 

Fuente: Historia del Arte.- Figueroba.- Mc Graw Hill.- 2004 así como en la decoración doméstica y del interior de los edificios. El estilo es sinuoso, con reminiscencias vegetales. 

GAUDÍ: El caso de Antonio Gaudí en Barcelona merece mención aparte, y aunque se le puede ubicar en el modernismo, su obra combina el gótico medioeval con influencias islámicas y presencia de figuras vegetales e inspiración en la naturaleza para realizar su obra. Ejemplos de obra: Parque Güell Casa Batlló Casa Milá Templo expiatorio de la Sagrada Familia.- Esta es su obra más famosa, a pesar de que el artista falleció antes de haberla visto concluida. Está formada por un conjunto de columnas arborescente inclinadas, cuyas ramas sujetan un follaje de bóvedas. La más impactante es la fachada del Nacimiento, con cuatro torres una portada tripartita salpicada de motivos escultóricos del artista. Este edificio representa la culminación del modernismo catalán y está considerado como una de las mejores obras arquitectónicas de todos los tiempos. 

Las vanguardias históricas I 
Circunstancias históricas y características principales.- 
 El siglo XX -ya agonizante, por cierto-, se caracteriza por ser un arte de vanguardia, siempre innovador, siempre insatisfecho. En este tiempo sucede que la pintura y la escultura se cuestionan y reflexionan sobre su técnica y lenguaje. La principal de sus dudas es la representación: comenzaron a preguntarse por qué el arte tenía que ser figurativo, por qué no podía ser distinto... así, el siglo XX dejó de ofrecer arte de "representación" para ser de "presentación". No re-presento lo que ya existe... simplemente presento lo que hago. 

 Asimismo, comienza a aparecer algo llamado "primitivismo" que implica la inspiración en el arte de las culturas primitivas y la revalorización de éstas, como puede ser el arte africano o las manifestaciones precolombinas en el Continente Americano. 

 Hechos históricos como la Revolución Rusa y la I Guerra Mundial, marcaron las crisis sociopolíticas, las diversas ideologías y las numerosas contradicciones en las representaciones artísticas. 

 Las influencias científicas del momento fueron Freud y sus interpretación de los sueños, y Einstein y la teoría de la relatividad. 

PRINCIPALES CORRIENTES PICTÒRICAS: 
 Fauvismo El fauvismo aparece en el Salón de Otoño de París de 1905 y se caracteriza por el color intenso y estridente de las obras, el apasionamiento de los artistas en ser intensos. Los fauvistas utilizaron los mismos temas de los impresionistas, pero prescindiendo de la armonía clásica y de la profundidad. 

Henri Matisse: Es el más representativo de los fauvistas franceses. Caracterizan su estilo figurativo temas como el de la mujer, odaliscas, interiores, ventanas, desnudos, etc. También practicó la escenografía, decoración y escultura. Utilizó colores básicos y composiciones sencillas. Obra: Retrato con línea verde.- La danza.- Mujer con sombrero. 

- 34 - 

Fuente: Historia del Arte.- Figueroba.- Mc Graw Hill.- 2004 Cubismo El cubismo aparece a principios de siglo y proviene de la "precisión de los cubos" que se refiere a que el todo puede descomponerse o reducirse a esquemas geométricos o cubos. Hay dos tipos o "etapas" del cubismo: analítico y *sintético*. En el primero, las formas se separan y descomponen, mientras que en el segundo, las masas se juntan y organizan de forma orgánica. Artistas: Francis Braque, *Picasso* (quien desarrolló, entre otras técnicas, el cubismo) y Juan Gris. 

 Futurismo El futurismo puede ser considerado un "cubismo dinámico" porque tiene la intención de representar el dinamismo interno de un mismo objeto, al multiplicar las posiciones del mismo, del mismo modo que lo hacía el cine primitivo. Artistas: Umberto *Boccioni* Un caso: Pablo Picasso Su obra y su personalidad son un caso aparte en la historia de la plástica universal. Renovador incansable, incasillable en un solo estilo, Picasso no sigue una línea evolutiva con su arte sino un camino lleno de variaciones. Principales etapas: Epoca de aprendizaje.- Sus primeros temas fueron los taurinos, influenciado por el color vivo del fauvismo. Etapa azul.- Es la etapa en la que Picasso pinta el color de la tristeza: personajes miserables, menesterosos, mendigos, etc. Obra: La Celestina. Etapa rosa.- Picasso cambia a un paisaje menos desolador, al abordar el tema de la maternidad, de gran delicadeza, así como al de los saltimbanquis y cirqueros, de multicolores vestidos tamizados tonos por una pálida tonalidad pastel. Obra: Los Saltimbanquis. Etapa cubista.- Con la influencia del arte escultórico africano, Picasso se fascina y comienza a apostar por la forma geométrica, sintetizada en grandes planos. Obra: Las señoritas de Avignón. 

Etapa neoclásica.- Con reminiscencias de los temas del clasicismo. 

Etapa surrealista.- Con notable redundancia en los temas tarurinos. 

Etapa expresionista.- En la que Picasso convierte las figuras en símbolos del sufrimiento mediante trazos angulosos y agudos, cuya violencia revela su espíritu atormentado. Obra: el Guernica, el cuadro-denuncia por los ataques a la población vasca del mismo nombre durante la guerra civil. 

Las vanguardias históricas II 
 Expresionismo Originalmente considerado el arte empeñado en la renovaciòn polìtica y social de la Alemania del principio del siglo XX, es un movimiento que ha causado gran huella en la historia de la plástica y permanece hasta nuestros días. Sin embargo, está plenamente 
- 35 - 

Fuente: Historia del Arte.- Figueroba.- Mc Graw Hill.- 2004 identificado con Alemania, con la inconformidad y con una franca oposición al impresionismo. Sus principales características plásticas son una aplicación violenta de la pasta cromática (semejante a los fauvés o fauvistas) y tendencias hacia lo morboso, lo prohibido o fantástico. Los expresionistas: Edward Munch, Vassily Kandinky, Paul Klee, Oscar Kokoschka Edward Munch: Este noruego es considerado el padre del expresionismo. Su obra muestra claras obsesiones por la enfermedad y la muerte; y en ellas plasma a seres inquietantes que huyen y se sacuden entre una masa de color que abruma. Obra: El grito Vassily Kandinky: En su pintura, la forma y el tema pierden importancia frente al protagonismo que adquiere el color: fuerte, libre, violento y real. Más adelante, evolucionará hacia la abstracción geométrica creciente. Obra: Rayas y círculos verdes. 

Paul Klee: El caso de Paul Klee, éste combina la abstracción con alusiones figurativas reconocibles. Su vocabulario pictórico lo aproxima al surrealismo de Miró. Obra: Villa Italiana Oscar Kokoschka: De origen vienés, vive en Alemania donde se dedica a los dos géneros que ocuparon la mayor parte de su creación: el retrato psicológico y el paisaje, además de los clásicos: mujer, pareja, amor y muerte. Obra: Pol Perro Dadaísmo Movimiento que surgió con un grupo de artistas que se reunían en el café Voltaire de Zurich. Emplearon nuevas técnicas como el fotomontaje, el collage, la esculptopintura y una técnica de última llamada "ready made" que consiste en que un objeto de uso común, en el que la intervención del artista en su mínima intervención –una firma, una fecha– lo convierte en una obra de arte. El término "Dadá" significa todo y nada a la vez... Artista: *Marcel Duchamp* Surrealismo La palabra surrealista fue usada por primera vez en 1917, como un término originalmente literario, luego llevado a la pintura hacia 1925. La pintura surrealista es puro automatismo psíquico, sueños, pensamientos, sin control directo de la razón. 

Precursores: Henry Rousseau, Marc Chagall, *Giorgio De Chirico* Se generalizaron dos tipos de surrealismo: 
Surrealistas figurativos Utilizan los convencionalismos de las perspectivas del renacimiento, para mostrar sorprendentes escenas. 

Principales autores: 
- 36 - 

Fuente: Historia del Arte.- Figueroba.- Mc Graw Hill.- 2004 René Magritte.- Combina lo extraño, los insólito y lo cotidiano, lo erótico y macabro, violando sistemáticamente los límites entre la realidad y la apariencia. En sus cuadros se contraponen sistemáticamente elementos conceptuales diferentes Salvador Dalí.- Gran genio del surrealismo, llega a dominar el dibujo a la perfección, mismo que utiliza para plasmar perfectamente en la pintura toda la tensión producida por sus temores y obsesiones. Entre otras recurrencias, están su pavor al contacto físico con el sexo contrario, su obsesión por la muerte y la putrefacciónn, el tema del angelus de Millet, los comestibles, en imágenes como la boca, la carne, la mujer asociada a las chuletas, el huevo (como paradigma de toda materia blanda) el pan (como estereotipo de lo que se desmiga). Al final de su vida, adquiere gran misticismo y aborda temas religiosos y temas clàsicos de amor y muerte. Obras: Muchacha asomada a la ventana, La premonición de la guerra, El gran masturbador, La permanencia de la Memoria, Cristo de San Juan de la Cruz, Mae West y numerosos retratos de Gala, su compañera inseparable. 

Surrealistas abstractos Inventan universos figurativos personales. Los principales autores son Max Ernst y Joan Miró. 

 La Abstracción La abstracción o arte abstracto prescinde por completo de los elementos figurativos y de las formas reconocibles, para concentrar la fuerza expresiva en formas y colores que no observan relación con la realidad visual: la obra no representa hombres, paisajes ni flores, sino combinaciones de colores que constituyen un lenguaje de formas, que puede ser geométrico u orgánico, manchas, puntos, rayas o trazos sin orden específico. Autor: *Piet Mondrian (el neoplasticismo)* Es el más famoso de los artistas abstractos de la vanguardia pictórica; su obra repite en sus lienzos, diversas variantes de rectángulos de colores de distintos tamaños a base de colores primarios, combinados con blanco y negro. En sus cuadros, Mondrian elimina la profundidad, limitándolos a los planos horizontal y vertical. Ejemplo: Tableau II 
El presente 
(1945-2001) 
 Características generales En los últimos años, las artes han evolucionado como parte de procesos rápidos y cambiantes: los acontecimientos se dan muy cercanos entre sí de manera tal que no permiten tener perspectiva histórica de cada momento. Abundan los artistas y las tendencias, abunda un deseo constante por ser "innovador", vanguardista, escandaloso o propositivo, abunda –también y lamentablemente- el esnobismo y hay una serie de fenómenos extra-artísticos que resultan muy importantes para la producción plástica, como pueden ser el desarrollo de la crítica de arte, la abundancia del análisis artístico y el crecimiento y desarrollo de la cultura de masas. 

Principales géneros nuevos que evolucionan en la segunda mitad del Siglo XX 
La fotografía El Cartel El cómic El cine 
- 37 - 

Fuente: Historia del Arte.- Figueroba.- Mc Graw Hill.- 2004 Tendencias informalistas:
Expresionismo abstracto.- Utiliza el formato a gran escala, su principal difusor es Jackson Pollock y entre sus principales características está su olvido del mundo material y una actitud pesimista después de la guerra. Exponente: *Jackson Pollock*. 

Arte óptico y cinegético.- Tiene la finalidad de crear un efecto interactivo con el espectador. Produce efectos visuales que causan sensaciones de tercera dimensiòn a partir de una configuración generalmente geométrica. 

"Body Art".- Son acciones calificadas por muchos como "sadomasoquistas" que se basan en brutales0 experiencias de automutilación. Los artistas que pertenecieron a eta tendencia se realizaban incisiones en distintas partes del cuerpo y después basaban sus obras con la sangra de las heridas. Muchas de estas acciones poseen un sentido ritual y sexual. 

Land Art.- La idea es actuar "sobre la naturaleza", corrigiendo perspecticas, cavando zanjas o empaquetando grandes objetos, en pocos días. El autor más conocido fue Christo, pero desafortunadametne las obras pueden ser vistas por pocas personas. 

Pop Art.- Tiene la característica de ser popular, tomar temas de la cultura calljera con preferencia por los estereotipos y convertirlos en protagonistas del cuadro. El pop art busca la máxima simplificación y, en una palabra, hacer uso de lo que se ha despreciado siempre. Autores: Roy Lichtenstein, Andy Warhol y *Oldenburg* (escultura) 
Nueva Figuración:
El hiperrealismo.- A finales de los años sesenta, en Estados Unidos y como reacciòn a los informalistas,un heterogéneo grupo de artistas comenzó a trabajar en un acusado realismo, aplicando una temática que abarca desde retratos hasta paisajes, figura humana, o el automóvil. 