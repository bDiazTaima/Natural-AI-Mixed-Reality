import torch
torch.cuda.empty_cache()
import torchvision
from transformers import AutoModelForVision2Seq, AutoProcessor, BitsAndBytesConfig
import requests
import sys
import os
import json
import glob
from PIL import Image
from datasets import Dataset
from datasets import load_dataset

os.environ["CUDA_LAUNCH_BLOCKING"] = "1"

if len(sys.argv) < 2:
    print("Usage: python trainModel.py <model_name>")
    sys.exit(1)

model_name = sys.argv[1]

dataset_file_path = os.path.join(os.getcwd(), "pdf_usr_uploads", model_name, f"{model_name}-data", f"{model_name}_dataset.json")

if not os.path.exists(dataset_file_path):
    print(f"Error: Dataset file '{dataset_file_path}' does not exist.")
    sys.exit(1)

with open(dataset_file_path, "r", encoding="utf-8") as f:
    dataset = json.load(f)

if not isinstance(dataset, list) or not all("message" in entry for entry in dataset):
    print(f"Error: Dataset file '{dataset_file_path}' is not in the expected format.")
    sys.exit(1)

def format_data(sample):
    return {"messages": sample["message"]}

processed_dataset = [format_data(entry) for entry in dataset]

image_folders = [
    "training_set/painting/",
    "training_set/sculpture/",
    "training_set/drawings/",
    "training_set/iconography/",
    "training_set/engraving/",
]

all_image_paths = []
for folder in image_folders:
    all_image_paths.extend(glob.glob(os.path.join(folder, "*.jpg")))  # Adjust extension if needed

if len(all_image_paths) >= len(processed_dataset):
    selected_image_paths = all_image_paths[:len(processed_dataset)]
else:
    raise ValueError("Not enough images in the dataset to assign one to each processed entry.")

for idx, entry in enumerate(processed_dataset):
    entry["image"] = selected_image_paths[idx]


hf_dataset = Dataset.from_dict({"messages": [entry["messages"] for entry in processed_dataset]})

print("Sample message from the dataset:")
print(processed_dataset[0]["messages"])

print("\nDataset successfully loaded and processed.")

model_id = "meta-llama/Llama-3.2-11B-Vision-Instruct" 

bnb_config = BitsAndBytesConfig(
    load_in_4bit=True, bnb_4bit_use_double_quant=True, bnb_4bit_quant_type="nf4", bnb_4bit_compute_dtype=torch.bfloat16
)

model = AutoModelForVision2Seq.from_pretrained(
    model_id,
    device_map="auto",
    torch_dtype=torch.bfloat16,
    quantization_config=bnb_config
)
processor = AutoProcessor.from_pretrained(model_id)

from peft import LoraConfig

peft_config = LoraConfig(
    lora_alpha=16,
    lora_dropout=0.05,
    r=8,
    bias="none",
    target_modules=["q_proj", "v_proj"],
    task_type="CAUSAL_LM",
)

from trl import SFTConfig
from transformers import Qwen2VLProcessor
from qwen_vl_utils import process_vision_info

args = SFTConfig(
    output_dir="llama-instruct-custom-dataset",  # Directory to save the fine-tuned model
    num_train_epochs=3,                          # Number of training epochs
    per_device_train_batch_size=4,               # Batch size per device during training
    gradient_accumulation_steps=8,               # Gradient accumulation steps
    gradient_checkpointing=True,                 # Use gradient checkpointing to save memory
    optim="adamw_torch_fused",                   # Fused AdamW optimizer
    logging_steps=5,                             # Log every 5 steps
    save_strategy="epoch",                       # Save checkpoints every epoch
    learning_rate=2e-4,                          # Learning rate based on LoRA best practices
    bf16=True,                                   # Use bfloat16 precision
    tf32=True,                                   # Use tf32 precision
    max_grad_norm=0.3,                           # Gradient clipping
    warmup_ratio=0.03,                           # Warmup ratio for learning rate scheduler
    lr_scheduler_type="constant",                # Constant learning rate
    push_to_hub=False,                           # Push model to Hugging Face Hub (set to True if desired)
    report_to="tensorboard",                     # Report metrics to TensorBoard
    gradient_checkpointing_kwargs={"use_reentrant": False},  # Use reentrant checkpointing
    max_seq_length=1024,                         # Maximum sequence length
    dataset_text_field="messages",               # Field in the dataset that contains text
    dataset_kwargs={"skip_prepare_dataset": True},  # Important for the collator
)
args.remove_unused_columns = False  # Ensure unused columns are not removed from the dataset

def collate_fn(examples):
    texts = [
        processor.apply_chat_template(
            example["messages"], tokenize=False
        )
        for example in examples
    ]
    images = [Image.open(example["image"]).convert("RGB") for example in examples]

    batch = processor(text=texts, images=images, return_tensors="pt", padding=True)

    labels = batch["input_ids"].clone()
    labels[labels == processor.tokenizer.pad_token_id] = -100  # Ignore padding tokens in loss computation

    image_tokens = [151652, 151653, 151655]  # Example image token IDs for this processor
    for image_token_id in image_tokens:
        labels[labels == image_token_id] = -100
    batch["labels"] = labels

    return batch

def collate_fn(examples):
    texts = [
        processor.apply_chat_template(
            example["messages"], tokenize=False
        )
        for example in examples
    ]
    images = [Image.open(example["image"]).convert("RGB") for example in examples]

    batch = processor(text=texts, images=images, return_tensors="pt", padding=True)

    labels = batch["input_ids"].clone()
    labels[labels == processor.tokenizer.pad_token_id] = -100  # Ignore padding tokens

    labels[labels >= processor.tokenizer.vocab_size] = -100

    print("Labels shape:", labels.shape)
    print("Labels unique values:", torch.unique(labels))
    print("Tokenizer vocab size:", processor.tokenizer.vocab_size)

    vocab_size = processor.tokenizer.vocab_size
    assert labels.max() < vocab_size, f"Invalid label index found: {labels.max()} >= vocab_size ({vocab_size})"
    assert labels.min() >= -100, f"Invalid label index found: {labels.min()} < -100"

    batch["labels"] = labels
    return batch




from trl import SFTTrainer
from tqdm import tqdm

trainer = SFTTrainer(
    model=model,                             # Preloaded LLaMA model
    args=args,                               # Fine-tuning arguments from SFTConfig
    train_dataset=processed_dataset,         # Custom database
    data_collator=collate_fn,                # Data collator for batching and formatting
    peft_config=peft_config,                 # LoRA configuration
    tokenizer=processor.tokenizer,           # Tokenizer from the preloaded processor
)

num_training_steps = len(trainer.get_train_dataloader()) * args.num_train_epochs
progress_bar = tqdm(total=num_training_steps, desc="Training Progress", unit="step")

original_train_step = trainer.training_step

def wrapped_train_step(*args, **kwargs):
    result = original_train_step(*args, **kwargs)
    progress_bar.update(1)  # Update progress bar by 1 step
    return result

trainer.training_step = wrapped_train_step

try:
    trainer.train()
finally:
    progress_bar.close()  # Ensure the progress bar closes properly

model.save_pretrained("lora_model")
processor.tokenizer.save_pretrained("lora_model")
