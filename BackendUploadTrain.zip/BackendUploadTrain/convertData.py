import os
import sys
import json

if len(sys.argv) < 2:
    print("Usage: python convertData.py <model_name>")
    sys.exit(1)

model_name = sys.argv[1]

base_dir = os.path.join(os.getcwd(), "pdf_usr_uploads", model_name, f"{model_name}-data")

if not os.path.exists(base_dir):
    print(f"Error: Directory '{base_dir}' does not exist.")
    sys.exit(1)

dataset = []

for folder_name in os.listdir(base_dir):
    folder_path = os.path.join(base_dir, folder_name)
    
    if os.path.isdir(folder_path):
        md_file_path = os.path.join(folder_path, f"{folder_name}.md")
        if os.path.isfile(md_file_path):
            with open(md_file_path, "r", encoding="utf-8") as f:
                text = f.read()
            
            lines = text.split("\n")
            for line in lines:
                if line.strip():  # Skip empty lines
                    tmp2 = [
                        {"role": "user", "content": [
                            {"type": "image"},
                            {"type": "text", "text": "¿Podrías explicar lo que estoy viendo?"}
                        ]},
                        {"role": "assistant", "content": [
                            {"type": "text", "text": line.strip()}
                        ]}
                    ]
                    
                    dataset.append({"message": tmp2})

output_file = os.path.join(base_dir, f"{model_name}_dataset.json")
with open(output_file, "w", encoding="utf-8") as f:
    json.dump(dataset, f, indent=4, ensure_ascii=False)

print(f"Dataset successfully created and saved to {output_file}")


